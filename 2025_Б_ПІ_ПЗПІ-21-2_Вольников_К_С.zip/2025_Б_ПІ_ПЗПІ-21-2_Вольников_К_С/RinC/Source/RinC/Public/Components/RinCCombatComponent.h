// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ActiveGameplayEffectHandle.h"
#include "RinCCombatComponent.generated.h"

DECLARE_MULTICAST_DELEGATE(FOnCharacterTurnEndedSignature);

class ARinCBaseCharacter;
struct FAbilityEndedData;
class ARinCFloatingTextActor;
class ARinCBattleCamera;
class UAbilitySystemComponent;

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class RINC_API URinCCombatComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	URinCCombatComponent();

public:	
    void TryStartCharacterTurn(ARinCBaseCharacter* TurnCharacter);

    UFUNCTION()
    void EndCharacterTurn();

    UFUNCTION(BlueprintPure)
    ARinCBaseCharacter* GetSelectedTargetCharacter() const;

    FORCEINLINE TArray<ARinCBaseCharacter*> GetCurrentTargetList() const { return CurrentTargetList; };

    /* Should be set by the currently executed ability */
    UFUNCTION(BlueprintCallable)
    void SetCurrentTargetList(bool bTargetAllies);

    void ClearCurrentTargetListAndSelectedTarget();

    FORCEINLINE uint32 GetSelectedTargetId() const { return SelectedTargetId; };

    void SetTargetCharacterById(uint32 Id);

    UFUNCTION(BlueprintCallable)
    void SetBattleCameraDefaultFocus(ARinCBaseCharacter* FocusCharacter);

    UFUNCTION(BlueprintCallable)
    void SetBattleCameraAttackFocus(ARinCBaseCharacter* OtherCharacter);

    UFUNCTION(BlueprintCallable)
    void SetBattleCameraBuffFocus(ARinCBaseCharacter* OtherCharacter);

    UFUNCTION(BlueprintCallable)
    void HandleAbilityConfirm();

    void SpawnFloatingTextActor(const FString& InString, FTransform SpawnTransform);

    UFUNCTION(BlueprintCallable)
    void AddActiveGameplayEffect(FActiveGameplayEffectHandle NewEffectHandle);

protected:
	virtual void BeginPlay() override;

    /* Initially setups battle camera for player controller based on current target list received from the current ability */
    void SetInitialBattleCameraTargetView();

    void HandleMonsterTurn();

    UFUNCTION()
    void OnAbilityEnded(const FAbilityEndedData& AbilityEndedData);

private:
    UAbilitySystemComponent* GetOwnerASC();

    ARinCBattleCamera* GetBattleCamera();

    /* Removes all temporary effects that were applied during the battle */
    void RemoveBattleActiveGameplayEffects();

public:
    FOnCharacterTurnEndedSignature OnCharacterTurnEnded;

protected:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC", meta = (AllowPrivateAccess = "true"))
    TSubclassOf<ARinCFloatingTextActor> FloatingTextActorClass;

private:
    ARinCBaseCharacter* SelectedTargetCharacter;

    TArray<ARinCBaseCharacter*> CurrentTargetList;

    uint32 SelectedTargetId;

    bool bIsCurrentAbilityTargetingAllies;

    UPROPERTY()
    FTimerHandle MonsterTurnTimerHandle;

    /* Handles of the temporary effects that were applied during the battle */
    TArray<FActiveGameplayEffectHandle> ActiveGameplayEffectHandles;
};
