// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Cartridges/Helpers/RinCCartridgeType.h"
#include "Miscellaneous/RinCResourceLoader.h"
#include "DataAssets/RinCCartridgeData.h"
#include "RinCPartyInventoryComponent.generated.h"

class ARinCBaseHeroCharacter;
class UNiagaraSystem;
class ARinCBaseCartridge;
class URinCCartridgeData;

DECLARE_MULTICAST_DELEGATE_OneParam(FOnCurrentPartyHeroesChangedSignature, TArray<ARinCBaseHeroCharacter*>/*CurrentPartyHeroes*/);
DECLARE_MULTICAST_DELEGATE_OneParam(FOnStoredCartridgesChangedSignature, FRinCStoredCartridges/*StoredCartridges*/);

USTRUCT()
struct FRinCStoredCartridges
{
    GENERATED_BODY()

    TMap<ERinCCartridgeType, TArray<ARinCBaseCartridge*>> StoredCartridges;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class RINC_API URinCPartyInventoryComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	URinCPartyInventoryComponent();

    FORCEINLINE TArray<ARinCBaseHeroCharacter*> GetCurrentPartyHeroes() { return CurrentPartyHeroes; }

    FRinCStoredCartridges GetAllStoredCartridges();

    TArray<ARinCBaseCartridge*> GetStoredCartridgesByType(ERinCCartridgeType Type);

    void HidePartyHeroes();

    void SwitchToNextHero();

    void SetActiveHero(int32 HeroIndex, ARinCBaseHeroCharacter* PrevHero = nullptr);

    void InitializeHeroParty();

    void StoreCartridge(ARinCBaseCartridge* CartridgeToStore);

    void StoreCartridges(TArray<ARinCBaseCartridge*> CartridgesToStore);

    void UseCartridge(ARinCBaseCartridge* CartridgeToUse);

    /* 
    *  Replaces a given party hero to the next hero from UnusedHeroClasses queue
    *  Returns a new hero, that was added to the party
    */
    ARinCBaseHeroCharacter* ReplacePartyHero(ARinCBaseHeroCharacter* HeroToReplace);

protected:
	virtual void BeginPlay() override;

private:
    void StoreCartridgeInternal(ARinCBaseCartridge* CartridgeToStore);

    void StoreCartridgesInternal(TArray<ARinCBaseCartridge*> CartridgesToStore);

    void UseCartridgeInternal(ARinCBaseCartridge* CartridgeToUse);

    void StoreInitialCartridges(TArray<FPrimaryAssetId> InitialCartridgesDataIds);

    void StoreInitialCartridgeInternal(FPrimaryAssetId LoadedCartridgeDataId);

    void InitUnusedHeroClasses();

    void UnequipAllHeroCartridges(ARinCBaseHeroCharacter* Hero);

    ARinCBaseHeroCharacter* SpawnHeroFromClass(TSubclassOf<ARinCBaseHeroCharacter> HeroClass);

    void HideHero(ARinCBaseHeroCharacter* Hero);

    void ShowHero(ARinCBaseHeroCharacter* Hero);

public:
    FOnCurrentPartyHeroesChangedSignature OnCurrentPartyHeroesChanged;

    FOnStoredCartridgesChangedSignature OnStoredCartridgesChanged;

private:
    TArray<ARinCBaseHeroCharacter*> CurrentPartyHeroes;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Heroes", meta = (AllowPrivateAccess = "true"))
    TArray<TSubclassOf<ARinCBaseHeroCharacter>> StartingHeroClasses;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Heroes", meta = (AllowPrivateAccess = "true"))
    TArray<TSubclassOf<ARinCBaseHeroCharacter>> AllAvaliableHeroClasses;

    TArray<TSubclassOf<ARinCBaseHeroCharacter>> UnusedHeroClasses;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Heroes", meta = (AllowPrivateAccess = "true"))
    int32 HeroPartySize;

    int32 CurrentHeroIndex;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Heroes", meta = (AllowPrivateAccess = "true"))
    UNiagaraSystem* HeroSwitchEffect;

    TMap<ERinCCartridgeType, TArray<ARinCBaseCartridge*>> StoredCartridges;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Cartridges", meta = (AllowPrivateAccess = "true"))
    TArray<FPrimaryAssetId> InitialCartridgesDataIds;
};
