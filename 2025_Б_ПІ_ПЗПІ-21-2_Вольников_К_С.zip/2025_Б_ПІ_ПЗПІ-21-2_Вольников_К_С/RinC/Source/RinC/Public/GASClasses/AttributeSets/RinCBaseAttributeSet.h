// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AttributeSet.h"
#include "AbilitySystemComponent.h"
#include "RinCBaseAttributeSet.generated.h"

#define ATTRIBUTE_ACCESSORS(ClassName, PropertyName)\
    GAMEPLAYATTRIBUTE_PROPERTY_GETTER(ClassName, PropertyName)\
    GAMEPLAYATTRIBUTE_VALUE_GETTER(PropertyName)\
    GAMEPLAYATTRIBUTE_VALUE_SETTER(PropertyName)\
    GAMEPLAYATTRIBUTE_VALUE_INITTER(PropertyName)

UCLASS()
class RINC_API URinCBaseAttributeSet : public UAttributeSet
{
	GENERATED_BODY()

public:
    /* Used for CurrentValue changes */
    virtual void PreAttributeChange(const FGameplayAttribute& Attribute, float& NewValue) override;

    /* Used for CurrentValue changes */
    virtual void PostAttributeChange(const FGameplayAttribute& Attribute, float OldValue, float NewValue) override;

    /* Used for handling meta attributes (Damage, etc.) */
    virtual void PostGameplayEffectExecute(const FGameplayEffectModCallbackData& Data) override;

protected:
    void ClampAttributeBaseValues(const FGameplayEffectModCallbackData& Data);
	
public:
    /* 
        Current Health, when 0 we expect owner to die. Capped by MaxHealth.
        Positive changes can directly use this.
        Negative changes to Health should go through Damage meta attribute. 
    */
    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData Health;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, Health);

    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData HealthMax;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, HealthMax);

    /* Damage meta attribute */
    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData Damage;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, Damage); 

    /* Current Morale, has range from 0-100% */
    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData Morale;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, Morale); 

    /* Max Morale, should be 100% */
    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData MoraleMax;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, MoraleMax); 

    /* MoraleThreshold, has range from 0-100%, used for morale-based damage reduction */
    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData MoraleThreshold;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, MoraleThreshold); 

    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData Energy;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, Energy);

    /* EnergyBase is a base energy amount, while Energy can be changed during a battle */
    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData EnergyBase;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, EnergyBase);

    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData Attack;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, Attack);

    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData Speed;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, Speed);

    /* Defense, has range from 0-100%, used for absorbing incoming damage */
    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData Defense;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, Defense); 

    /* CritChance, has range from 0-100%, used to add additional damage multiplier, for example 1.5 */
    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData CritChance;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, CritChance); 

    /* DodgeChance, has range from 0-100%, gives small chance to completely dodge incoming damage */
    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData DodgeChance;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, DodgeChance); 

    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData ActionPoints;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, ActionPoints);

    UPROPERTY(BlueprintReadOnly, Category = "RinC|Attributes")
    FGameplayAttributeData ActionPointsMax;
    ATTRIBUTE_ACCESSORS(URinCBaseAttributeSet, ActionPointsMax);
};
