// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "GameplayModMagnitudeCalculation.h"
#include "RinCActionPointsCostMagCalc.generated.h"

UCLASS()
class RINC_API URinCActionPointsCostMagCalc : public UGameplayModMagnitudeCalculation
{
	GENERATED_BODY()
	
protected:
    float CalculateBaseMagnitude_Implementation(const FGameplayEffectSpec& Spec) const override;
};
