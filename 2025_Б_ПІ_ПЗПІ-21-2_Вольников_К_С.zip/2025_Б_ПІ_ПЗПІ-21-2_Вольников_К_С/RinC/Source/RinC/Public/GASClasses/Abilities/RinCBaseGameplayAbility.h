// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Abilities/GameplayAbility.h"
#include "RinCBaseGameplayAbility.generated.h"

UCLASS()
class RINC_API URinCBaseGameplayAbility : public UGameplayAbility
{
	GENERATED_BODY()

public:
    /** Checks cost. returns true if we can pay for the ability. False if not */
    virtual bool CheckCost(const FGameplayAbilitySpecHandle Handle, const FGameplayAbilityActorInfo* ActorInfo, OUT FGameplayTagContainer* OptionalRelevantTags = nullptr) const override;

public:
    UPROPERTY(EditDefaultsOnly, meta = (ClampMin = 0))
    float ActionPointCost;

    UPROPERTY(EditDefaultsOnly, meta = (ClampMin = 0))
    float EnergyCost;

    UPROPERTY(EditDefaultsOnly, meta = (ClampMin = 0))
    TSoftClassPtr<UUserWidget> SoftCostCheckFailedWidget;
	
};
