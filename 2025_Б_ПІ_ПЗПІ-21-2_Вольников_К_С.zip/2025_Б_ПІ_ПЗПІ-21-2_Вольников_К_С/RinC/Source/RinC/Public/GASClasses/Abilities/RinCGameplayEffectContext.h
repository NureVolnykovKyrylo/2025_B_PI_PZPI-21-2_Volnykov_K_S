// My copyright notice

#pragma once

#include "GameplayTagContainer.h"
#include "AbilitySystemGlobals.h"
#include "RinCGameplayEffectContext.generated.h"

USTRUCT()
struct RINC_API FRinCGameplayEffectContext : public FGameplayEffectContext
{
    GENERATED_USTRUCT_BODY()

public:
    FGameplayTag GetElementTypeTag() { return ElementTypeTag; }
    void SetElementTypeTag(const FGameplayTag& Tag) { ElementTypeTag = Tag; }

    bool GetIsCrit() { return bIsCrit; }
    void SetIsCrit(bool IsCrit) { bIsCrit = IsCrit; }

    bool GetWasDodged() { return bWasDodged; }
    void SetWasDodged(bool WasDodged) { bWasDodged = WasDodged; }

protected:
    FGameplayTag ElementTypeTag;

    bool bIsCrit = false;

    bool bWasDodged = false;

    /**
    * Functions that subclasses of FGameplayEffectContext need to override
    */
public:
    virtual UScriptStruct* GetScriptStruct() const override
    {
        return FRinCGameplayEffectContext::StaticStruct();
    }

    virtual FRinCGameplayEffectContext* Duplicate() const override
    {
        FRinCGameplayEffectContext* NewContext = new FRinCGameplayEffectContext();
        *NewContext = *this;
        NewContext->AddActors(Actors);

        if (GetHitResult())
        {
            // Does a deep copy of the hit result
            NewContext->AddHitResult(*GetHitResult(), true);
        }

        NewContext->ElementTypeTag = ElementTypeTag;
        NewContext->bIsCrit = bIsCrit;
        NewContext->bWasDodged = bWasDodged;

        return NewContext;
    }
};

template<>
struct TStructOpsTypeTraits<FRinCGameplayEffectContext> : public TStructOpsTypeTraitsBase2<FRinCGameplayEffectContext>
{
    enum
    {
        WithNetSerializer = true,
        WithCopy = true		// Necessary so that TSharedPtr<FHitResult> Data is copied around
    };
};
