// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "AbilitySystemGlobals.h"
#include "RinCAbilitySystemGlobals.generated.h"

UCLASS()
class RINC_API URinCAbilitySystemGlobals : public UAbilitySystemGlobals
{
	GENERATED_BODY()
	
    /** Should allocate a project specific GameplayEffectContext struct. Caller is responsible for deallocation */
    virtual FGameplayEffectContext* AllocGameplayEffectContext() const override;
};
