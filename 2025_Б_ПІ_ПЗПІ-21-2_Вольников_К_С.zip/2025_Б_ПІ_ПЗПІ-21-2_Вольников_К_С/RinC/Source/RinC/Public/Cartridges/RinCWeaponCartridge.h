// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Cartridges/RinCBaseCartridge.h"
#include "RinCWeaponCartridge.generated.h"

UCLASS()
class RINC_API ARinCWeaponCartridge : public ARinCBaseCartridge
{
	GENERATED_BODY()
	
};
