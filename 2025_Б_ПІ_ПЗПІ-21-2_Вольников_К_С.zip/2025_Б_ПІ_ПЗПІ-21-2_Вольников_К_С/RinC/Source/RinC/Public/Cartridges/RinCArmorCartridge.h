// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Cartridges/RinCBaseCartridge.h"
#include "RinCArmorCartridge.generated.h"

UCLASS()
class RINC_API ARinCArmorCartridge : public ARinCBaseCartridge
{
	GENERATED_BODY()
	
};
