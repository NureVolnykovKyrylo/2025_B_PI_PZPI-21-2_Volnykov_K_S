// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "GameplayTagContainer.h"
#include "Core/HUD/RinCLayerType.h"
#include "RinCUIManagerSubsystem.generated.h"

class URinCPrimaryLayoutWidget;
class URinCBaseLayerWidget;

UCLASS()
class RINC_API URinCUIManagerSubsystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()
	
public:
    FORCEINLINE void SetWeakPrimaryLayoutWidget(TWeakObjectPtr<URinCPrimaryLayoutWidget> LayoutWidget) { WeakPrimaryLayoutWidget = LayoutWidget; }

    FORCEINLINE TWeakObjectPtr<URinCPrimaryLayoutWidget> GetWeakPrimaryLayoutWidget() { return WeakPrimaryLayoutWidget; }

    void RegisterLayer(ERinCLayerType LayerType, URinCBaseLayerWidget* LayerWidget);

    void UnRegisterLayer(ERinCLayerType LayerType);

    UFUNCTION(BlueprintCallable)
    void PushContentToLayer(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass);

    /* 
        Instead of pushing a new widget right away, checks if there is already a widget of this class in 
        layer's stack at the top, if so, just shows already existing widget
    */
    void PushContentToLayerWithCheck(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass);

    /*
        Returns true if the specified widget is at the top of the layer's stack and is collapsed
    */
    bool IsContentCollapsedInLayer(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass);

    UFUNCTION(BlueprintCallable)
    void PopContentFromLayer(ERinCLayerType LayerType);

    /* Collapses the widget which is at the top of the layer's stack */
    void CollapseContentInLayer(ERinCLayerType LayerType);

private:
    TWeakObjectPtr<URinCPrimaryLayoutWidget> WeakPrimaryLayoutWidget;
};
