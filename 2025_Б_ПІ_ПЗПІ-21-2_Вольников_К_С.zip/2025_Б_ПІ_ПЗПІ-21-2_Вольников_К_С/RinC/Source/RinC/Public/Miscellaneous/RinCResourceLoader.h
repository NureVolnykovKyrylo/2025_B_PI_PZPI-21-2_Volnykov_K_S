// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Engine/StreamableManager.h"

class RINC_API RinCResourceLoader
{
public:
    static TSharedPtr<FStreamableHandle> RequestAsyncLoad(const FSoftObjectPath& TargetToStream, FStreamableDelegate DelegateToCall = FStreamableDelegate());

    static TSharedPtr<FStreamableHandle> RequestAsyncLoad(TArray<FSoftObjectPath> TargetsToStream, FStreamableDelegate DelegateToCall = FStreamableDelegate());

    static TSharedPtr<FStreamableHandle> LoadPrimaryAsset(const FPrimaryAssetId& AssetToLoad, const TArray<FName>& LoadBundles = TArray<FName>(), 
        FStreamableDelegate DelegateToCall = FStreamableDelegate(), TAsyncLoadPriority Priority = FStreamableManager::DefaultAsyncLoadPriority);

    static TSharedPtr<FStreamableHandle> LoadPrimaryAssets(const TArray<FPrimaryAssetId>& AssetsToLoad, const TArray<FName>& LoadBundles = TArray<FName>(),
        FStreamableDelegate DelegateToCall = FStreamableDelegate(), TAsyncLoadPriority Priority = FStreamableManager::DefaultAsyncLoadPriority);

    static UObject* GetPrimaryAssetObject(const FPrimaryAssetId& PrimaryAssetId);

    /**
     * Executes a callback function with a loaded asset of DataClass type
     * If the asset is not loaded, it will load it first, then execute the callback
     * This version supports callbacks with additional parameters using Unreal's delegate system
     *
     * @param Object - The UObject instance to use for callback binding
     * @param AssetId - The asset ID to load
     * @param Callback - The member function to call after ensuring the asset is loaded
     * @param Bundles - Optional bundles to load with the asset
     * @param Vars - Additional variables to pass to the callback
     */
    template<class DataClass, class UserClass, typename... VarTypes>
    static void ExecuteWithLoadedAsset(FPrimaryAssetId AssetId, const TArray<FName>& Bundles, UserClass* Object,
        typename TMemFunPtrType<false, UserClass, void(VarTypes...)>::Type Callback, VarTypes... Vars)
    {
        static_assert(!TIsConst<UserClass>::Value, "Attempting to bind a callback with a const object pointer and non-const member function.");

        DataClass* Data = Cast<DataClass>(RinCResourceLoader::GetPrimaryAssetObject(AssetId));
        if (IsValid(Data))
        {
            /* Asset already loaded, execute callback immediately */
            (Object->*Callback)(Vars...);
        }
        else
        {
            /* Asset not loaded, load it first then execute callback */
            FStreamableDelegate Delegate = FStreamableDelegate::CreateUObject(Object, Callback, Vars...);
            RinCResourceLoader::LoadPrimaryAsset(AssetId, Bundles, Delegate);
        }
    }
};
