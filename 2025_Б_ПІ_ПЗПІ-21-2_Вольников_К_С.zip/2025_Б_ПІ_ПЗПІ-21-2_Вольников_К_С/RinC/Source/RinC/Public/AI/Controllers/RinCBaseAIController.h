// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "RinCBaseAIController.generated.h"

class UBehaviorTreeComponent;

UCLASS()
class RINC_API ARinCBaseAIController : public AAIController
{
	GENERATED_BODY()

public:
    ARinCBaseAIController();

    /* Convinience method to run BT outside of the controller */
    void RunBattleBehaviorTree();

    void StopBattleBehaviorTree();

private:
    UPROPERTY(EditDefaultsOnly, Category = "RinC", meta = (AllowPrivateAccess = "true"))
    UBehaviorTreeComponent* BehaviorTreeComponent;

    UPROPERTY(EditDefaultsOnly, Category = "RinC", meta = (AllowPrivateAccess = "true"))
    UBlackboardComponent* BlackboardComponent;
};
