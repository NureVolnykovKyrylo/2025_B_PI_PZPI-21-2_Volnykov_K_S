// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Tasks/BTTask_BlackboardBase.h"
#include "GameplayTagContainer.h"
#include "RinCSelectAbilityTargetBTT.generated.h"

class URinCBaseAttributeSet;
class AAIController;

UCLASS()
class RINC_API URinCSelectAbilityTargetBTT : public UBTTask_BlackboardBase
{
	GENERATED_BODY()
	
public:
    URinCSelectAbilityTargetBTT();

protected:
    virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
    FGameplayTag TryGetUsedAbilityElementalTag(AAIController* OwnerAIController, const FGameplayTag& ElementParentTag);

    float CalculateTargetPriority(const URinCBaseAttributeSet* TargetAttributeSet, const FGameplayTag& AbilityElementTag, const FGameplayTag& TargetElementTag);

    float GetElementalMultiplier(const FGameplayTag& AbilityElementTag, const FGameplayTag& TargetElementTag);
};
