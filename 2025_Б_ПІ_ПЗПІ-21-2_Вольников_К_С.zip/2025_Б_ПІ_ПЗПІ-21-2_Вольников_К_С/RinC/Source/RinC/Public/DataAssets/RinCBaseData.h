// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "RinCBaseData.generated.h"

UCLASS()
class RINC_API URinCBaseData : public UPrimaryDataAsset
{
	GENERATED_BODY()
	
public:
    FPrimaryAssetId GetPrimaryAssetId() const override;

public:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Display")
    FText DisplayName;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Display")
    FText Description;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Display")
    UMaterialInterface* Icon;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Display")
    UMaterialInterface* Portrait;
};
