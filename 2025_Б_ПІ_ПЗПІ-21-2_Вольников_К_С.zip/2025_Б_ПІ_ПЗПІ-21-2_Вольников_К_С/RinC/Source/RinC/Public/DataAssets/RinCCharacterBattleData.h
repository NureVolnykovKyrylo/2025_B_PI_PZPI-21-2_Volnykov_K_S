// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "GameplayTagContainer.h"
#include "RinCCharacterBattleData.generated.h"

class UNiagaraSystem;

UCLASS()
class RINC_API URinCCharacterBattleData : public UDataAsset
{
	GENERATED_BODY()
	
public:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TArray<UAnimMontage*> DeathMontages;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TArray<UAnimMontage*> HitReactMontages;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TArray<UAnimMontage*> AttackMontages;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TArray<UAnimMontage*> BuffMontages;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    UNiagaraSystem* DeathNiagara;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    FGameplayTag CharacterElementTag;
};
