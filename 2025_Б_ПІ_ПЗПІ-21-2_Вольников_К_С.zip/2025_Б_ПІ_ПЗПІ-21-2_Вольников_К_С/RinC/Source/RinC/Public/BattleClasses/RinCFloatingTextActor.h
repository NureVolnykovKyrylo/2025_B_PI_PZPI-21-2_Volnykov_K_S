// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RinCFloatingTextActor.generated.h"

class UWidgetComponent;

UCLASS()
class RINC_API ARinCFloatingTextActor : public AActor
{
	GENERATED_BODY()
	
public:	
	ARinCFloatingTextActor();

public:
    FORCEINLINE void SetFloatingTextString(const FString& InString) { FloatingString = InString; }

    UFUNCTION(BlueprintImplementableEvent)
    void MoveWithLerpAndDestroy();

protected:
    virtual void BeginPlay() override;

protected:
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components", meta = (AllowPrivateAccess = "true"))
    USceneComponent* CustomRoot;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components", meta = (AllowPrivateAccess = "true"))
    UWidgetComponent* FloatingTextWidgetComponent;

    UPROPERTY(BlueprintReadOnly, Category = "RinC")
    FString FloatingString;
};
