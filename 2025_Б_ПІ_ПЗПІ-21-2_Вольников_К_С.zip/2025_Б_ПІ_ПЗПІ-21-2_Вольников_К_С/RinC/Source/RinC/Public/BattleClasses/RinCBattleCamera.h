// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RinCBattleCamera.generated.h"

class USpringArmComponent;
class UCameraComponent;
class USceneComponent;

UCLASS()
class RINC_API ARinCBattleCamera : public AActor
{
	GENERATED_BODY()
	
public:	
	ARinCBattleCamera();

public:	
    FORCEINLINE class USpringArmComponent* GetCameraBoom() const { return CameraBoom; }

    FORCEINLINE class UCameraComponent* GetFollowCamera() const { return FollowCamera; }

    FORCEINLINE class USceneComponent* GetBattleCameraRoot() const { return BattleCameraRoot; }

    void SetDynamicPosition(AActor* PositionActor);

    void SetFollowCameraLookToRotation(AActor* LookToActor);

    UFUNCTION(BlueprintImplementableEvent)
    void SetFollowCameraLookToRotationWithLerp(FRotator InitialRotation, FRotator NewRotation);

    void SetFollowCameraInFrontOfActor(AActor* PositionActor);

    void SetLookToRotation(AActor* LookToActor);

    UFUNCTION(BlueprintImplementableEvent)
    void SetLookToRotationWithLerp(FRotator InitialRotation, FRotator NewRotation);

protected:
	virtual void BeginPlay() override;

    void ResetComponentsTransform();

protected:
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera", meta = (AllowPrivateAccess = "true"))
    USpringArmComponent* CameraBoom;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera", meta = (AllowPrivateAccess = "true"))
    UCameraComponent* FollowCamera;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components", meta = (AllowPrivateAccess = "true"))
    USceneComponent* BattleCameraRoot;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Camera", meta = (AllowPrivateAccess = "true"))
    float InFrontOfPositionDistance;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Camera", meta = (AllowPrivateAccess = "true"))
    float InFrontOfPositionHeight;

private:
    FVector DefaultFollowCameraRelativeLocation;

    FRotator DefaultFollowCameraRelativeRotation;
};
