// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RinCBattleHelperHeroOpposite.generated.h"

class UCapsuleComponent;

UCLASS()
class RINC_API ARinCBattleHelperHeroOpposite : public AActor
{
	GENERATED_BODY()
	
public:	
	ARinCBattleHelperHeroOpposite();

protected:
    virtual void BeginPlay() override;

    UFUNCTION()
    void OnComponentBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

protected:
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components", meta = (AllowPrivateAccess = "true"))
    UCapsuleComponent* HelperHeroOppositeCapsule;

};
