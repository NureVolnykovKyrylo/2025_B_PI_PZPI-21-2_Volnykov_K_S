// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Engine/StreamableManager.h"
#include "RinCBaseBattleArena.generated.h"

class ARinCBaseBattlePosition;
class ARinCBaseCharacter;
class ARinCBaseHeroCharacter;
class UBoxComponent;
class ARinCBattleHelperHeroOpposite;
class ARinCBaseMonsterCharacter;
class ARinCBaseCartridge;

DECLARE_MULTICAST_DELEGATE(FOnPrepareFaseChangedSignature);

DECLARE_LOG_CATEGORY_EXTERN(LogARinCBaseBattleArena, Log, All);

USTRUCT(BlueprintType)
struct FRinCMonsterSpawnInfo
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadOnly)
    TSoftClassPtr<ARinCBaseMonsterCharacter> MonsterSoftClass;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, meta = (ClampMin = "0.0", ClampMax = "100.0"))
    float SpawnProbability = 100.0f;
};

UCLASS()
class RINC_API ARinCBaseBattleArena : public AActor
{
	GENERATED_BODY()
	
public:	
	ARinCBaseBattleArena();

public:
    FORCEINLINE TArray<ARinCBaseCharacter*> GetBattleCharacters() const { return BattleCharacters; };

    FORCEINLINE TArray<ARinCBaseCharacter*> GetBattleHeroCharacters() const { return BattleHeroCharacters; };

    FORCEINLINE TArray<ARinCBaseCharacter*> GetBattleMonsterCharacters() const { return BattleMonsterCharacters; };

    FORCEINLINE ARinCBattleHelperHeroOpposite* GetBattleHelperHeroOpposite() const { return BattleHelperHeroOpposite; };

    FORCEINLINE void SetBattleHelperHeroOpposite(ARinCBattleHelperHeroOpposite* BattleHelper) { BattleHelperHeroOpposite = BattleHelper; };

    void AddBattlePosition(ARinCBaseBattlePosition* const BattlePosition);

    void SetupBattleArena();

    void TemporaryDisableArena(float Seconds);

protected:
	virtual void BeginPlay() override;

    UFUNCTION()
    void OnComponentBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

private:
    void SetupMonsters();

    void SetupMonstersInternal(TArray<TSoftClassPtr<ARinCBaseMonsterCharacter>> SoftMonsterClasses);

    void PositionHeroes();

    void PositionMonsters(const TArray<TSoftClassPtr<ARinCBaseMonsterCharacter>>& SoftMonsterClasses);

    void GrantRandomCartridgesToMonsters();

    TSoftClassPtr<ARinCBaseMonsterCharacter> GetRandomMonsterClass();

    TArray<FPrimaryAssetId> GetRandomCartridgeIds();

    void EquipLoadedCartridges(TArray<FPrimaryAssetId> CartridgeDataIds);

    ARinCBaseCartridge* SpawnCartridgeFromData(FPrimaryAssetId CartridgeDataId);

    void DistributeCartridgesToEquipEvenly(const TArray<ARinCBaseCartridge*>& CartridgesToEquip);

    void ReEnableArena();

public:
    FOnPrepareFaseChangedSignature OnPrepareBattleStarted;

    FOnPrepareFaseChangedSignature OnPrepareBattleEnded;

protected:
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components", meta = (AllowPrivateAccess = "true"))
    UBoxComponent* BattleArenaOverlapBox;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "RinC|Battle", meta = (AllowPrivateAccess = "true"))
    TArray<FPrimaryAssetId> CartridgePool;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "RinC|Battle", meta = (AllowPrivateAccess = "true"))
    TArray<FRinCMonsterSpawnInfo> MonsterPool;

private:
    TArray<ARinCBaseBattlePosition*> MonsterBattlePositions;

    TArray<ARinCBaseBattlePosition*> HeroBattlePositions;

    TArray<ARinCBaseHeroCharacter*> HeroesToPosition;

    TArray<ARinCBaseCharacter*> BattleCharacters;

    TArray<ARinCBaseCharacter*> BattleHeroCharacters;

    TArray<ARinCBaseCharacter*> BattleMonsterCharacters;

    UPROPERTY()
    ARinCBattleHelperHeroOpposite* BattleHelperHeroOpposite;

    UPROPERTY()
    FTimerHandle RestoreCollisionTimerHandle;

    TSharedPtr<FStreamableHandle> MonsterLoadHandle;

    bool bIsArenaDisabled;
};
