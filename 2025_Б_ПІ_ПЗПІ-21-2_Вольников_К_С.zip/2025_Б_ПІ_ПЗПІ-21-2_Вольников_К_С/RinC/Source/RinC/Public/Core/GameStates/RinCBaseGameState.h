// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameStateBase.h"
#include "RinCBaseGameState.generated.h"

class ARinCBaseCharacter;
class ARinCBaseBattleArena;
class ARinCBaseCartridge;
class UGameplayEffect;
class UAbilitySystemComponent;

DECLARE_MULTICAST_DELEGATE(OnBattleEventTrigeredSignature);
DECLARE_MULTICAST_DELEGATE_OneParam(OnTurnStartSignature, ARinCBaseCharacter*/*TurnCharacter*/);

UCLASS()
class RINC_API ARinCBaseGameState : public AGameStateBase
{
	GENERATED_BODY()

public:
    ARinCBaseGameState();

public:
    FORCEINLINE void SetCurrentBattleArena(ARinCBaseBattleArena* BattleArena) { CurrentBattleArena = BattleArena; };

    FORCEINLINE ARinCBaseBattleArena* GetCurrentBattleArena() { return CurrentBattleArena; }

    FORCEINLINE TArray<ARinCBaseCharacter*> GetCurrentAliveHeroCharacters() { return CurrentAliveHeroCharacters; }

    FORCEINLINE TArray<ARinCBaseCharacter*> GetCurrentAliveMonsterCharacters() { return CurrentAliveMonsterCharacters; }

    FORCEINLINE TSoftClassPtr<UUserWidget> GetBattleTransitionWidget() { return SoftBattleTransitionWidget; }

    void GrantRetrievedCartridges();

    /* Should be called after SetupBattleArena call for CurrentBattleArena */
    void InitAliveCharactersLists();

    void RemoveFromAliveHeroCharacters(ARinCBaseCharacter* const CharacterToRemove);

    void RemoveFromAliveMonsterCharacters(ARinCBaseCharacter* const CharacterToRemove);

    void ExecuteQueueTurn();

    void ResetRoundStats(TWeakObjectPtr<UAbilitySystemComponent> WeakASC);

    void ResetStatsAfterBattle(TWeakObjectPtr<UAbilitySystemComponent> WeakASC);

protected:
    virtual void BeginPlay();

private:
    void StartNewRound();

    void RemoveFromCurrentQueueTurnOrder(ARinCBaseCharacter* const CharacterToRemove);

    bool CheckDeadCharacters();

    void RetrieveCartridgesFromMonster(ARinCBaseCharacter* Monster);

    void EndBattle(bool bWon);

    void ApplyBattleGameplayEffect(UAbilitySystemComponent* ASC, TSubclassOf<UGameplayEffect> GameplayEffect);

public:
    OnBattleEventTrigeredSignature OnBattleStarted;

    OnBattleEventTrigeredSignature OnBattleEnded;

    OnBattleEventTrigeredSignature OnRoundEnded;

    OnTurnStartSignature OnTurnStart;

    OnBattleEventTrigeredSignature OnCartirdgesGranted;
	
private:
    UPROPERTY(EditDefaultsOnly, Category = "RinC", meta = (AllowPrivateAccess = true))
    TSubclassOf<UGameplayEffect> ResetRoundStatsGameplayEffect;

    UPROPERTY(EditDefaultsOnly, Category = "RinC", meta = (AllowPrivateAccess = true))
    TSubclassOf<UGameplayEffect> ResetStatsAfterBattleGameplayEffect;

    UPROPERTY(EditDefaultsOnly, Category = "RinC", meta = (AllowPrivateAccess = true))
    TSoftClassPtr<UUserWidget> SoftBattleTransitionWidget;

    TArray<ARinCBaseCharacter*> CurrentQueueTurnOrder;

    UPROPERTY()
    ARinCBaseBattleArena* CurrentBattleArena;

    TArray<ARinCBaseCharacter*> CurrentAliveHeroCharacters;

    TArray<ARinCBaseCharacter*> CurrentAliveMonsterCharacters;

    TArray<ARinCBaseCartridge*> RetrievedCartridges;
};
