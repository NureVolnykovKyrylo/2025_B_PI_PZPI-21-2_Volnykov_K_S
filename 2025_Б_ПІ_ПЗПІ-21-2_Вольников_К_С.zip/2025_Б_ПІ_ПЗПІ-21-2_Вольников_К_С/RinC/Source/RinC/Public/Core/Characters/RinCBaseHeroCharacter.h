// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Core/Characters/RinCBaseCharacter.h"
#include "GASClasses/Helpers/RinCAbilityInput.h"
#include "RinCBaseHeroCharacter.generated.h"

class URinCCharacterInputs;

UCLASS()
class RINC_API ARinCBaseHeroCharacter : public ARinCBaseCharacter
{
	GENERATED_BODY()
	
public:
    ARinCBaseHeroCharacter();

protected:
    void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;

    void Move(const FInputActionValue& Value);

    void Look(const FInputActionValue& Value);

    void AbilityInputBindingPressedHandler(ERinCAbilityInput AbilityInput);

    virtual void HandleDeath() override;

private:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    URinCCharacterInputs* CharacterInputs;
};
