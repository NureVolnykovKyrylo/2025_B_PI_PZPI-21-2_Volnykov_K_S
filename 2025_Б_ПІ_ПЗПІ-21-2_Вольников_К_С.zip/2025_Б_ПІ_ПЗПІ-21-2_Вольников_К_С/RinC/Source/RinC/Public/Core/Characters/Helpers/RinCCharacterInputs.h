// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "RinCCharacterInputs.generated.h"

class URinCAbilityInputBindings;
class UInputAction;

UCLASS()
class RINC_API URinCCharacterInputs : public UDataAsset
{
	GENERATED_BODY()
	
public:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    UInputAction* JumpAction;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    UInputAction* MoveAction;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    UInputAction* LookAction;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    URinCAbilityInputBindings* AbilityInputBindings;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    UInputAction* ConfirmCharacterAbilityAction;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "RinC|Input", meta = (AllowPrivateAccess = "true"))
    UInputAction* EndCharacterTurnAction;
};
