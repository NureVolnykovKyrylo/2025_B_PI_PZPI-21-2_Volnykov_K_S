// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "UI/BattleWidgets/RinCBaseStatusWidget.h"
#include "RinCHeroStatusWidget.generated.h"

class URinCObjectSlotWidget;
class UTextBlock;
class ARinCBaseCharacter;

UCLASS()
class RINC_API URinCHeroStatusWidget : public URinCBaseStatusWidget
{
	GENERATED_BODY()

public:
    void UpdateEnergy(float NewEnergy);

    void UpdateCharacterSlot(ARinCBaseCharacter* SlotCharacter);

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCObjectSlotWidget* CharacterSlot;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UTextBlock* CurrentEnergyText;
};
