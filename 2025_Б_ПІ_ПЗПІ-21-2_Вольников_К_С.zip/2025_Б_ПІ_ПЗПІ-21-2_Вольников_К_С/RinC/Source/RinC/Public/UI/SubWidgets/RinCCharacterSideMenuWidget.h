// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "RinCCharacterSideMenuWidget.generated.h"

class URinCObjectSlotWidget;
class ARinCBaseHeroCharacter;

UCLASS()
class RINC_API URinCCharacterSideMenuWidget : public UUserWidget
{
	GENERATED_BODY()

public:
    void UpdateCurrentCharacterSlots(const TArray<ARinCBaseHeroCharacter*>& CurrentHeroCharacters, bool bShowPortrait = false);

    FORCEINLINE TArray<URinCObjectSlotWidget*> GetCurrentCharacterSlots() const { return CurrentCharacterSlots; }
	
protected:
    virtual void NativeConstruct() override;

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCObjectSlotWidget* CurrentCharacter1;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCObjectSlotWidget* CurrentCharacter2;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCObjectSlotWidget* CurrentCharacter3;

private:
    TArray<URinCObjectSlotWidget*> CurrentCharacterSlots;
};
