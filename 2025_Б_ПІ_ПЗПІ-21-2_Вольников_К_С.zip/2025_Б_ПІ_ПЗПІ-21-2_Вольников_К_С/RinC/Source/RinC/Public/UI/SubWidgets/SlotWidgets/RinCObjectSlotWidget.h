// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "UI/SubWidgets/SlotWidgets/RinCBaseSlotWidget.h"
#include "Cartridges/Helpers/RinCCartridgeType.h"
#include "RinCObjectSlotWidget.generated.h"

DECLARE_MULTICAST_DELEGATE_TwoParams(FOnObjectSlotClickedSignature, UObject*/*StoredObject*/, URinCObjectSlotWidget*/*ClickedSlot*/);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnIsActiveChangedSignature, bool, IsActive);

UCLASS()
class RINC_API URinCObjectSlotWidget : public URinCBaseSlotWidget
{
	GENERATED_BODY()

public:
    void SetStoredObject(UObject* Object, bool bShowPortrait = false);
    FORCEINLINE UObject* GetStoredObject() const { return StoredObject; }

    FOnObjectSlotClickedSignature OnSlotClickedLMB;
    FOnObjectSlotClickedSignature OnSlotClickedRMB;

    UPROPERTY(BlueprintAssignable)
    FOnIsActiveChangedSignature OnIsActiveChanged;

    FORCEINLINE void SetSlotCartridgeType(ERinCCartridgeType Type) { SlotCartridgeType = Type; }
    FORCEINLINE ERinCCartridgeType GetSlotCartridgeType() { return SlotCartridgeType; }

    void SetIsActive(bool IsActive);
    FORCEINLINE bool GetIsActive() const { return bIsActive; }

    virtual void ClearSlot() override;

protected:
    virtual void NativeConstruct() override;

    virtual FReply NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;

private:
    UPROPERTY()
    UObject* StoredObject;

    ERinCCartridgeType SlotCartridgeType;

    UPROPERTY(BlueprintReadWrite, meta = (AllowPrivateAccess = true))
    bool bIsActive;
};
