// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "UI/GameMenus/RinCBaseGameMenuWidget.h"
#include "RinCCharacterSelectMenuWidget.generated.h"

class URinCCharacterMenuLayoutWidget;

UCLASS()
class RINC_API URinCCharacterSelectMenuWidget : public URinCBaseGameMenuWidget
{
	GENERATED_BODY()

protected:
    virtual void NativeConstruct() override;

    virtual void UpdateCurrentCharacters(TArray<ARinCBaseHeroCharacter*> CurrentHeroCharacters) override;

    virtual void HandleCharacterSlotSelect(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot) override;

    void OnCharacterSlotClickedRMB(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot);
};
