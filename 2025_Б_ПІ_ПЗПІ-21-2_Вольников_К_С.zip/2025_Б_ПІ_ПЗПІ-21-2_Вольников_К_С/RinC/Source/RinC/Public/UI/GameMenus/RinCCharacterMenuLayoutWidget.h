// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "RinCCharacterMenuLayoutWidget.generated.h"

class URinCButtonWidget;
class URinCCharacterInfoMenuWidget;
class URinCCharacterSelectMenuWidget;
class URinCCharacterSetupMenuWidget;

UCLASS()
class RINC_API URinCCharacterMenuLayoutWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
    virtual void NativeConstruct() override;
	
protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCButtonWidget* CharacterSelectButtonWidget;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCButtonWidget* CharacterSetupButtonWidget;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCButtonWidget* CharacterInfoButtonWidget;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCCharacterInfoMenuWidget* CharacterInfoMenuWidget;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCCharacterSelectMenuWidget* CharacterSelectMenuWidget;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    URinCCharacterSetupMenuWidget* CharacterSetupMenuWidget;
};
