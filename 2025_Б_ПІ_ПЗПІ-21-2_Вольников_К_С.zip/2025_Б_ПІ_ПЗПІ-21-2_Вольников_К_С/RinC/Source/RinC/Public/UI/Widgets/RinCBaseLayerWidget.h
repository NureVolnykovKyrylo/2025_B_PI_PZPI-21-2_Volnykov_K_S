// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "RinCBaseLayerWidget.generated.h"

class UBorder;

UCLASS()
class RINC_API URinCBaseLayerWidget : public UUserWidget
{
	GENERATED_BODY()

public:
    UUserWidget* PushContent(TSoftClassPtr<UUserWidget> SoftWidgetClass, bool bShowPushedContent = true);

    UUserWidget* PushContentWithCheck(TSoftClassPtr<UUserWidget> SoftWidgetClass);

    bool IsContentCollapsed(TSoftClassPtr<UUserWidget> SoftWidgetClass);

    void PopContent();

    UUserWidget* GetTop() const;

    void ShowTop();

    void CollapseTop();

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UBorder* ContainerBorder;

private:
    TArray<UUserWidget*> WidgetStack;
};
