// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "GameplayTagContainer.h"
#include "Core/HUD/RinCLayerType.h"
#include "RinCPrimaryLayoutWidget.generated.h"

class URinCBaseLayerWidget;

UCLASS()
class RINC_API URinCPrimaryLayoutWidget : public UUserWidget
{
	GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable)
    void PushInitialScreens();

    UFUNCTION(BlueprintCallable)
    void RegisterLayer(ERinCLayerType LayerType, URinCBaseLayerWidget* LayerWidget);

    void UnRegisterLayer(ERinCLayerType LayerType);

    void PushContentToLayer(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass, bool bShowPushedContent = true);

    void PushContentToLayerWithCheck(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass);

    bool IsContentCollapsedInLayer(ERinCLayerType LayerType, TSoftClassPtr<UUserWidget> SoftWidgetClass);

    void PopContentFromLayer(ERinCLayerType LayerType);

    void CollapseContentInLayer(ERinCLayerType LayerType);
	
protected:
    virtual void NativeConstruct() override;

protected:
    UPROPERTY(BlueprintReadWrite, meta = (BindWidget))
    URinCBaseLayerWidget* GameLayer;

    UPROPERTY(BlueprintReadWrite, meta = (BindWidget))
    URinCBaseLayerWidget* GameMenuLayer;

    UPROPERTY(BlueprintReadWrite, meta = (BindWidget))
    URinCBaseLayerWidget* MenuLayer;

    UPROPERTY(BlueprintReadWrite, meta = (BindWidget))
    URinCBaseLayerWidget* ModalLayer;

private:
    TMap<ERinCLayerType, URinCBaseLayerWidget*> LayersMap;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, meta = (AllowPrivateAccess = true))
    TMap<ERinCLayerType, TSoftClassPtr<UUserWidget>> InitialScreens;
};
