// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "RinCButtonWidget.generated.h"

class UButton;
class UTextBlock;

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnButtonClickedSignature);

UCLASS()
class RINC_API URinCButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
    UPROPERTY(BlueprintAssignable)
    FOnButtonClickedSignature OnButtonClicked;
	
protected:
    virtual void NativeConstruct() override;

private:
    UFUNCTION()
    void BroadcastButtonClick();

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UButton* BaseButton;

    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    UTextBlock* ButtonNameText;
};
