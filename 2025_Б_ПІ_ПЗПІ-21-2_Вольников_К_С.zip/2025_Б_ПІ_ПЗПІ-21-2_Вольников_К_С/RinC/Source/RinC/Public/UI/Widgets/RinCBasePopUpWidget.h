// My copyright notice

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "RinCBasePopUpWidget.generated.h"

/**
 * 
 */
UCLASS()
class RINC_API URinCBasePopUpWidget : public UUserWidget
{
	GENERATED_BODY()
	
};
