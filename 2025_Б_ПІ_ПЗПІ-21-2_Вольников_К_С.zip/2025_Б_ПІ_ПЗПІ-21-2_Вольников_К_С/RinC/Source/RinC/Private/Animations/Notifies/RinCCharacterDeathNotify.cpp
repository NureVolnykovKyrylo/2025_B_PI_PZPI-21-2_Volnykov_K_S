// My copyright notice

#include "Animations/Notifies/RinCCharacterDeathNotify.h"
#include "Characters/RinCBaseCharacter.h"
#include "Characters/RinCBaseMonsterCharacter.h"

void URinCCharacterDeathNotify::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
    Super::Notify(MeshComp, Animation, EventReference);

    if (!IsValid(MeshComp)) return;

    ARinCBaseCharacter* OwnerCharacter = MeshComp->GetOwner<ARinCBaseCharacter>();
    if (!IsValid(OwnerCharacter)) return;

    OwnerCharacter->SpawnDeathNiagara();

    if (OwnerCharacter->IsA<ARinCBaseMonsterCharacter>())
    {
        OwnerCharacter->OnCharacterDeath.Broadcast();
        OwnerCharacter->Destroy();
    }
    else
    {
        OwnerCharacter->OnCharacterDeath.Broadcast();
        OwnerCharacter->SetActorHiddenInGame(true);
        OwnerCharacter->SetActorEnableCollision(false);
    }
}
