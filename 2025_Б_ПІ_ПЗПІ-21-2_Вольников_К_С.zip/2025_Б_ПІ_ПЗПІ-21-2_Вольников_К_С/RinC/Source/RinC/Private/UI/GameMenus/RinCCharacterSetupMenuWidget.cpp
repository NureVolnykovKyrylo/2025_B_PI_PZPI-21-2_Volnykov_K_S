// My copyright notice

#include "UI/GameMenus/RinCCharacterSetupMenuWidget.h"
#include "Controllers/RinCBasePlayerController.h"
#include "RinCPartyInventoryComponent.h"
#include "UI/SubWidgets/RinCCharacterSideMenuWidget.h"
#include "UI/SubWidgets/RinCCartridgeDescriptionWidget.h"
#include "Characters/RinCBaseHeroCharacter.h"
#include "RinCCartridgeComponent.h"
#include "UI/SubWidgets/SlotWidgets/RinCObjectSlotWidget.h"
#include "Characters/RinCBaseCharacter.h"
#include "Components/WrapBox.h"
#include "Components/TextBlock.h"
#include "Cartridges/RinCBaseCartridge.h"

DEFINE_LOG_CATEGORY(LogURinCCharacterSetupMenuWidget);

void URinCCharacterSetupMenuWidget::NativeConstruct()
{
    Super::NativeConstruct();

    checkf(SlotWidgetClass, TEXT("SlotWidgetClass should be set!"))

    ArtifactSlots.Add(ArtifactSlot1);
    ArtifactSlots.Add(ArtifactSlot2);
    ArtifactSlots.Add(ArtifactSlot3);

    EquipmentSlots.Add(WeaponSlot);
    EquipmentSlots.Add(ArmorSlot);
    EquipmentSlots.Append(ArtifactSlots);

    WeaponSlot->OnSlotClickedLMB.AddUObject(this, &ThisClass::OnEquipmentSlotClickedLMB);
    WeaponSlot->OnSlotClickedRMB.AddUObject(this, &ThisClass::OnEquipmentSlotClickedRMB);
    WeaponSlot->SetSlotCartridgeType(ERinCCartridgeType::Weapon);

    ArmorSlot->OnSlotClickedLMB.AddUObject(this, &ThisClass::OnEquipmentSlotClickedLMB);
    ArmorSlot->OnSlotClickedRMB.AddUObject(this, &ThisClass::OnEquipmentSlotClickedRMB);
    ArmorSlot->SetSlotCartridgeType(ERinCCartridgeType::Armor);

    for (URinCObjectSlotWidget* ArtifactSlot : ArtifactSlots)
    {
        ArtifactSlot->OnSlotClickedLMB.AddUObject(this, &ThisClass::OnEquipmentSlotClickedLMB);
        ArtifactSlot->OnSlotClickedRMB.AddUObject(this, &ThisClass::OnEquipmentSlotClickedRMB);

        ArtifactSlot->SetSlotCartridgeType(ERinCCartridgeType::Artifact);
    }
}

void URinCCharacterSetupMenuWidget::OnEquipmentSlotClickedLMB(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot)
{
    if (!ClickedSlot) return;

    URinCPartyInventoryComponent* const PartyInventoryComponent = GetPartyInventoryComponent();
    if (!PartyInventoryComponent) return;

    URinCCartridgeData* const Data = GetCartridgeData(StoredObject);
    if (Data)
    {
        UpdateInventoryWrapBox(PartyInventoryComponent->GetStoredCartridgesByType(Data->CartridgeType));
    }

    if (ClickedSlot->GetSlotCartridgeType() != ERinCCartridgeType::None)
    {
        UpdateInventoryWrapBox(PartyInventoryComponent->GetStoredCartridgesByType(ClickedSlot->GetSlotCartridgeType()));
    }

    CartridgeDescriptionWidget->UpdateDescription(StoredObject, ClickedSlot);

    DeactivateSlots(EquipmentSlots);

    ClickedSlot->SetIsActive(true);
}

void URinCCharacterSetupMenuWidget::OnEquipmentSlotClickedRMB(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot)
{
    if (!SelectedCharacter) return;

    URinCPartyInventoryComponent* const PartyInventoryComponent = GetPartyInventoryComponent();
    if (!PartyInventoryComponent) return;

    URinCCartridgeComponent* const CartridgeComponent = SelectedCharacter->GetCartridgeComponent();
    if (!CartridgeComponent) return;

    URinCCartridgeData* const Data = GetCartridgeData(StoredObject);
    if (!Data) return;

    ERinCCartridgeType CartridgeType = Data->CartridgeType;

    CartridgeComponent->UnequipCartridge(Cast<ARinCBaseCartridge>(StoredObject));
    UpdateEquippedCartridges(SelectedCharacter);

    UpdateInventoryWrapBox(PartyInventoryComponent->GetStoredCartridgesByType(CartridgeType));
}

void URinCCharacterSetupMenuWidget::UpdateInventoryWrapBox(TArray<ARinCBaseCartridge*> StoredCartridges)
{
    InventoryWrapBox->ClearChildren();

    CreateSlotsForStoredCartridges(StoredCartridges);
}

void URinCCharacterSetupMenuWidget::UpdateInventoryWrapBox(FRinCStoredCartridges StoredCartridges)
{
    URinCPartyInventoryComponent* const PartyInventoryComponent = GetPartyInventoryComponent();
    if (!PartyInventoryComponent) return;

    InventoryWrapBox->ClearChildren();

    for (const auto& kv : StoredCartridges.StoredCartridges)
    {
        CreateSlotsForStoredCartridges(PartyInventoryComponent->GetStoredCartridgesByType(kv.Key));
    }
}

void URinCCharacterSetupMenuWidget::CreateSlotsForStoredCartridges(TArray<ARinCBaseCartridge*> StoredCartridges)
{
    for (int32 i = 0; i < StoredCartridges.Num(); i++)
    {
        URinCObjectSlotWidget* CartridgeSlotWidget = CreateWidget<URinCObjectSlotWidget>(this, SlotWidgetClass);
        if (!CartridgeSlotWidget) continue;

        InventoryWrapBox->AddChildToWrapBox(CartridgeSlotWidget);

        CartridgeSlotWidget->SetStoredObject(StoredCartridges[i]);

        CartridgeSlotWidget->OnSlotClickedLMB.AddUObject(CartridgeDescriptionWidget, &URinCCartridgeDescriptionWidget::UpdateDescription);
        CartridgeSlotWidget->OnSlotClickedRMB.AddUObject(this, &ThisClass::EquipCartridge);
    }
}

void URinCCharacterSetupMenuWidget::EquipCartridge(UObject* CartridgeObject, URinCObjectSlotWidget* ClickedSlot)
{
    ARinCBaseCartridge* CartridgeToEquip = Cast<ARinCBaseCartridge>(CartridgeObject);

    if (!IsValid(SelectedCharacter) || !IsValid(CartridgeToEquip)) return;

    URinCCartridgeComponent* CartridgeComponent = SelectedCharacter->GetCartridgeComponent();
    if (!CartridgeComponent) return;

    CartridgeComponent->EquipCartridge(CartridgeToEquip);
    UpdateEquippedCartridges(SelectedCharacter);

    FPrimaryAssetId CartridgeDataId = CartridgeToEquip->GetDataPrimaryAssetId();

    RinCResourceLoader::ExecuteWithLoadedAsset<URinCCartridgeData>(CartridgeDataId, TArray<FName>(),
        this, &ThisClass::UpdateInventoryOnCartridgeStateChange, CartridgeDataId);
}

void URinCCharacterSetupMenuWidget::UpdateEquippedCartridges(ARinCBaseCharacter* Character)
{
    if (!Character) return;

    ClearSlots(EquipmentSlots);

    URinCCartridgeComponent* const CartridgeComponent = Character->GetCartridgeComponent();
    if (!CartridgeComponent) return;

    /* Set currently equipped cartridges to the corresponding slots */
    int32 ArtifactSlotsCounter = 0;
    for (ARinCBaseCartridge* const Cartridge : CartridgeComponent->GetEquippedCartridges())
    {
        URinCCartridgeData* const Data = Cartridge->GetCartridgeData();
        if (!Data) continue;

        switch (Data->CartridgeType)
        {
        case ERinCCartridgeType::Weapon:
            if (!WeaponSlot) break;
            WeaponSlot->SetStoredObject(Cartridge);
            break;

        case ERinCCartridgeType::Armor:
            if (!ArmorSlot) break;
            ArmorSlot->SetStoredObject(Cartridge);
            break;

        case ERinCCartridgeType::Artifact:
            ArtifactSlots[ArtifactSlotsCounter]->SetStoredObject(Cartridge);
            ArtifactSlotsCounter += 1;
            break;

        case ERinCCartridgeType::None:
            break;

        default:
            break;
        }
    }

    /* Re-apply the IsActiveState if the equipment slot was equipped before the update */
    /*for (URinCObjectSlotWidget* EquipmentSlot : EquipmentSlots)
    {
        if (EquipmentSlot->GetIsActive()) EquipmentSlot->SetIsActive(true);
    }*/
    DeactivateSlots(EquipmentSlots);
}

URinCCartridgeData* URinCCharacterSetupMenuWidget::GetCartridgeData(UObject* InCartridge) const
{
    ARinCBaseCartridge* const StoredCartridge = Cast<ARinCBaseCartridge>(InCartridge);
    if (!StoredCartridge) return nullptr;

    if (!StoredCartridge->GetCartridgeData())
    {
        UE_LOG(LogURinCCharacterSetupMenuWidget, Error, TEXT("CartridgeData is invalid!"));
    }

    return StoredCartridge->GetCartridgeData();
}

void URinCCharacterSetupMenuWidget::UpdateCurrentCharacters(TArray<ARinCBaseHeroCharacter*> CurrentHeroCharacters)
{
    Super::UpdateCurrentCharacters(CurrentHeroCharacters);

    UpdateSelectedCharacter();

    UpdateEquippedCartridges(SelectedCharacter);
}

void URinCCharacterSetupMenuWidget::UpdateInventoryOnCartridgeStateChange(FPrimaryAssetId CartridgeAssetId)
{
    URinCCartridgeData* const Data = Cast<URinCCartridgeData>(RinCResourceLoader::GetPrimaryAssetObject(CartridgeAssetId));
    if (!IsValid(Data)) return;

    URinCPartyInventoryComponent* const PartyInventoryComponent = GetPartyInventoryComponent();
    if (!PartyInventoryComponent) return;

    UpdateInventoryWrapBox(PartyInventoryComponent->GetStoredCartridgesByType(Data->CartridgeType));
}

void URinCCharacterSetupMenuWidget::HandleCharacterSlotSelect(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot)
{
    Super::HandleCharacterSlotSelect(StoredObject, ClickedSlot);

    UpdateEquippedCartridges(Cast<ARinCBaseCharacter>(SelectedCharacter));

    /* Show all cartridges as a default inventory display */
    URinCPartyInventoryComponent* const PartyInventoryComponent = GetPartyInventoryComponent();
    if (!PartyInventoryComponent) return;

    UpdateInventoryWrapBox(PartyInventoryComponent->GetAllStoredCartridges());
}
