// My copyright notice


#include "UI/GameMenus/RinCCharacterSelectMenuWidget.h"
#include "UI/SubWidgets/RinCCharacterSideMenuWidget.h"
#include "UI/SubWidgets/SlotWidgets/RinCObjectSlotWidget.h"
#include "RinCPartyInventoryComponent.h"
#include "Characters/RinCBaseHeroCharacter.h"

void URinCCharacterSelectMenuWidget::NativeConstruct()
{
    Super::NativeConstruct();

    if (!IsValid(CharacterContainerWidget)) return;

    for (URinCObjectSlotWidget* CharacterSlot : CharacterContainerWidget->GetCurrentCharacterSlots())
    {
        CharacterSlot->OnSlotClickedRMB.AddUObject(this, &ThisClass::OnCharacterSlotClickedRMB);
    }
}

void URinCCharacterSelectMenuWidget::UpdateCurrentCharacters(TArray<ARinCBaseHeroCharacter*> CurrentHeroCharacters)
{
    if (!IsValid(CharacterContainerWidget)) return;

    CharacterContainerWidget->UpdateCurrentCharacterSlots(CurrentHeroCharacters, true);
}

void URinCCharacterSelectMenuWidget::HandleCharacterSlotSelect(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot)
{
    Super::HandleCharacterSlotSelect(StoredObject, ClickedSlot);
}

void URinCCharacterSelectMenuWidget::OnCharacterSlotClickedRMB(UObject* StoredObject, URinCObjectSlotWidget* ClickedSlot)
{
    if (!IsValid(ClickedSlot) || !IsValid(StoredObject)) return;

    if (!ClickedSlot->GetIsActive()) return;

    URinCPartyInventoryComponent* PartyInventoryComponent = GetPartyInventoryComponent();
    if (!IsValid(PartyInventoryComponent)) return;

    ARinCBaseHeroCharacter* NextSelectedHero = PartyInventoryComponent->ReplacePartyHero(Cast<ARinCBaseHeroCharacter>(StoredObject));

    ClickedSlot->SetStoredObject(NextSelectedHero, true);

    /* Re-apply the IsActiveState if the character slot was active before the update */
    for (URinCObjectSlotWidget* EquipmentSlot : CharacterContainerWidget->GetCurrentCharacterSlots())
    {
        if (EquipmentSlot->GetIsActive()) EquipmentSlot->SetIsActive(true);
    }

    SelectedCharacter = NextSelectedHero;
    UpdateSelectedCharacter();
}
