// My copyright notice

#include "UI/Widgets/RinCBaseLayerWidget.h"
#include "GameFramework/HUD.h"
#include "Blueprint/UserWidget.h"
#include "Components/Border.h"

UUserWidget* URinCBaseLayerWidget::PushContent(TSoftClassPtr<UUserWidget> SoftWidgetClass, bool bShowPushedContent)
{
    UClass* WidgetClass = nullptr;

    WidgetClass = SoftWidgetClass.Get();
    if (!WidgetClass)
    {
        /* TO DO make async load */
        WidgetClass = SoftWidgetClass.LoadSynchronous();
        if (!IsValid(WidgetClass)) return nullptr;
    }

    APlayerController* OwningPlayer = GetOwningPlayer();
    if (!IsValid(OwningPlayer)) return nullptr;

    UUserWidget* PushedWidget = CreateWidget<UUserWidget>(OwningPlayer, WidgetClass);
    
    CollapseTop();
    ContainerBorder->ClearChildren();

    WidgetStack.Add(PushedWidget);
    ContainerBorder->AddChild(GetTop());
    if (bShowPushedContent) ShowTop();

    return PushedWidget;
}

UUserWidget* URinCBaseLayerWidget::PushContentWithCheck(TSoftClassPtr<UUserWidget> SoftWidgetClass)
{
    UUserWidget* TopWidget = GetTop();
    if (!TopWidget) return nullptr;

    UClass* WidgetClass = nullptr;

    WidgetClass = SoftWidgetClass.Get();
    if (!WidgetClass)
    {
        /* TO DO make async load */
        WidgetClass = SoftWidgetClass.LoadSynchronous();
        if (!IsValid(WidgetClass)) return nullptr;
    }

    if (TopWidget->IsA(WidgetClass))
    {
        ShowTop();
        return TopWidget;
    }
    return PushContent(SoftWidgetClass);
}

bool URinCBaseLayerWidget::IsContentCollapsed(TSoftClassPtr<UUserWidget> SoftWidgetClass)
{
    UUserWidget* TopWidget = GetTop();
    if (!TopWidget) return false;

    UClass* WidgetClass = nullptr;

    WidgetClass = SoftWidgetClass.Get();
    if (!WidgetClass)
    {
        /* TO DO make async load */
        WidgetClass = SoftWidgetClass.LoadSynchronous();
        if (!IsValid(WidgetClass)) return false;
    }

    if (TopWidget->IsA(WidgetClass))
    {
        return TopWidget->GetVisibility() == ESlateVisibility::Collapsed;
    }
    return false;
}

void URinCBaseLayerWidget::PopContent()
{
    if (WidgetStack.IsEmpty()) return;

    UUserWidget* WidgetToRemove = GetTop();
    if (!IsValid(WidgetToRemove)) return;

    WidgetStack.RemoveAt(WidgetStack.Num() - 1);
    WidgetToRemove->RemoveFromParent();
    ContainerBorder->ClearChildren();

    ContainerBorder->AddChild(GetTop());
    ShowTop();
}

UUserWidget* URinCBaseLayerWidget::GetTop() const
{
    if (WidgetStack.IsEmpty() || !WidgetStack.IsValidIndex(WidgetStack.Num() - 1)) return nullptr;

    return WidgetStack[WidgetStack.Num() - 1];
}

void URinCBaseLayerWidget::ShowTop()
{
    UUserWidget* const TopWidget = GetTop();
    if (!IsValid(TopWidget)) return;

    TopWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void URinCBaseLayerWidget::CollapseTop()
{
    UUserWidget* const TopWidget = GetTop();
    if (!IsValid(TopWidget)) return;

    TopWidget->SetVisibility(ESlateVisibility::Collapsed);
}
