// Fill out your copyright notice in the Description page of Project Settings.

#include "UI/Widgets/RinCFloatingTextWidget.h"
#include "Components/TextBlock.h"
#include "Components/RichTextBlock.h"
#include "Styling/SlateColor.h"

void URinCFloatingTextWidget::UpdateFloatingText(const FString& InString)
{
    if (!IsValid(FloatingRichText)) return;

    FloatingRichText->SetText(FText::FromString(InString));
}

