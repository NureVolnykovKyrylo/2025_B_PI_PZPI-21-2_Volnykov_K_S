// My copyright notice

#include "UI/SubWidgets/SlotWidgets/RinCBaseSlotWidget.h"
#include "Components/Image.h"
#include "Components/Button.h"
#include "DataAssets/RinCBaseData.h"
#include "Miscellaneous/RinCResourceLoader.h"

void URinCBaseSlotWidget::NativePreConstruct()
{
    Super::NativePreConstruct();

    IconImage->SetBrushFromMaterial(PlaceholderImageMaterial);
}

void URinCBaseSlotWidget::UpdateIconImage(FPrimaryAssetId AssetId, bool bShowPortrait)
{
    /*URinCBaseData* const Data = Cast<URinCBaseData>(RinCResourceLoader::GetPrimaryAssetObject(AssetId));
    if (IsValid(Data))
    {
        UpdateIconImageInternal(AssetId);
    }
    else
    {
        FStreamableDelegate Delegate = FStreamableDelegate::CreateUObject(this, &ThisClass::UpdateIconImageInternal, AssetId);
        TArray<FName> Bundles;

        RinCResourceLoader::LoadPrimaryAsset(AssetId, Bundles, Delegate);
    }*/

    RinCResourceLoader::ExecuteWithLoadedAsset<URinCBaseData>(AssetId, TArray<FName>(), 
        this, &ThisClass::UpdateIconImageInternal, AssetId, bShowPortrait);
}

void URinCBaseSlotWidget::ClearSlot()
{
    checkf(PlaceholderImageMaterial, TEXT("PlaceholderImageMaterial should be set!"))

    IconImage->SetBrushFromMaterial(PlaceholderImageMaterial);
}

void URinCBaseSlotWidget::UpdateIconImageInternal(FPrimaryAssetId LoadedId, bool bShowPortrait)
{
    URinCBaseData* const Data = Cast<URinCBaseData>(RinCResourceLoader::GetPrimaryAssetObject(LoadedId));
    if (!IsValid(Data)) return;

    if (bShowPortrait)
    {
        IconImage->SetBrushFromMaterial(Data->Portrait);
    }
    else
    {
        IconImage->SetBrushFromMaterial(Data->Icon);
    }

}
