// My copyright notice

#include "UI/SubWidgets/RinCCartridgeDescriptionWidget.h"
#include "Cartridges/RinCBaseCartridge.h"
#include "DataAssets/RinCCartridgeData.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Miscellaneous/RinCResourceLoader.h"

void URinCCartridgeDescriptionWidget::UpdateDescription(UObject* CartridgeObject, URinCObjectSlotWidget* ClickedSlot)
{
    ARinCBaseCartridge* Cartridge = Cast<ARinCBaseCartridge>(CartridgeObject);
    if (!IsValid(Cartridge)) return;

    SetupDescription(Cartridge);
}

void URinCCartridgeDescriptionWidget::SetupDescription(ARinCBaseCartridge* Cartridge)
{
    if (!IsValid(Cartridge)) return;

    RinCResourceLoader::ExecuteWithLoadedAsset<URinCCartridgeData>(Cartridge->GetDataPrimaryAssetId(), TArray<FName>(), 
        this, &ThisClass::SetupDescriptionInternal, Cartridge);
}

void URinCCartridgeDescriptionWidget::SetupDescriptionInternal(ARinCBaseCartridge* Cartridge)
{
    if (!IsValid(Cartridge)) return;

    URinCCartridgeData* Data = Cast<URinCCartridgeData>(RinCResourceLoader::GetPrimaryAssetObject(Cartridge->GetDataPrimaryAssetId()));
    if (!IsValid(Data)) return;

    UpdateIconImage(Data->Icon);
    DisplayNameText->SetText(Data->DisplayName);
    DescriptionText->SetText(Data->Description);
    UpdateStatsText(Cartridge->GetAppliedStats());
}

void URinCCartridgeDescriptionWidget::UpdateIconImage(UMaterialInterface* Material)
{
    if (!Material) return;

    IconImage->SetBrushFromMaterial(Material);
}

void URinCCartridgeDescriptionWidget::UpdateStatsText(const TArray<FRinCAppliedCartridgeStat>& Stats)
{
    FString FormatedStatsString;
    for (const FRinCAppliedCartridgeStat& Stat : Stats)
    {
        FRinCStatDisplay StatDisplay = TagStatDisplayMap.FindChecked(Stat.StatTag);

        AppendStatToString(FormatedStatsString, StatDisplay.StatDisplayName, Stat.Magnitude, StatDisplay.bIsPercent);
    }

    StatsText->SetText(FText::FromString(FormatedStatsString));
}

void URinCCartridgeDescriptionWidget::AppendStatToString(FString& OutString, const FString& StatName, float Value, bool bIsPercentage)
{
    if (!OutString.IsEmpty()) OutString.Append(TEXT("\n"));

    const FString Sign = (Value >= 0.0f) ? TEXT("+") : TEXT("");

    if (bIsPercentage)
    {
        OutString.Append(FString::Printf(TEXT("%s: %s%.1f%%"), *StatName, *Sign, Value));
    }
    else
    {
        OutString.Append(FString::Printf(TEXT("%s: %s%.1f"), *StatName, *Sign, Value));
    }
}