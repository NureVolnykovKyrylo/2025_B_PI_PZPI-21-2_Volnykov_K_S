// My copyright notice

#include "UI/SubWidgets/SlotWidgets/RinCObjectSlotWidget.h"
#include "Interfaces/RinCAssetIdentifiable.h"

void URinCObjectSlotWidget::NativeConstruct()
{
    Super::NativeConstruct();

    SlotCartridgeType = ERinCCartridgeType::None;
    bIsActive = false;
}

void URinCObjectSlotWidget::SetStoredObject(UObject* Object, bool bShowPortrait)
{
    StoredObject = Object;

    IRinCAssetIdentifiable* AssetIdentifiable = Cast<IRinCAssetIdentifiable>(Object);
    if (AssetIdentifiable) UpdateIconImage(AssetIdentifiable->GetDataPrimaryAssetId(), bShowPortrait);

    UPrimaryDataAsset* DataAsset = Cast<UPrimaryDataAsset>(Object);
    if(IsValid(DataAsset)) UpdateIconImage(DataAsset->GetPrimaryAssetId(), bShowPortrait);
}

void URinCObjectSlotWidget::SetIsActive(bool IsActive)
{
    OnIsActiveChanged.Broadcast(IsActive);
}

void URinCObjectSlotWidget::ClearSlot()
{
    Super::ClearSlot();

    StoredObject = nullptr;
}

FReply URinCObjectSlotWidget::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
    if (InMouseEvent.IsMouseButtonDown(EKeys::LeftMouseButton))
    {
        OnSlotClickedLMB.Broadcast(StoredObject, this);
    }
    else if (InMouseEvent.IsMouseButtonDown(EKeys::RightMouseButton))
    {
        OnSlotClickedRMB.Broadcast(StoredObject, this);
    }

    return Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);
}
