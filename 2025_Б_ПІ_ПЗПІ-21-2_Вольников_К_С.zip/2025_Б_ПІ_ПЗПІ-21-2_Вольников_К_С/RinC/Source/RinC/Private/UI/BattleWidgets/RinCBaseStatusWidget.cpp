// My copyright notice

#include "UI/BattleWidgets/RinCBaseStatusWidget.h"
#include "Components/ProgressBar.h"
#include "Characters/RinCBaseCharacter.h"
#include "GASClasses/AttributeSets/RinCBaseAttributeSet.h"

void URinCBaseStatusWidget::UpdateHealth(float CurrentHealth, float MaxHealth)
{
    float HealthPercent = CurrentHealth / MaxHealth;
    SetSmoothProgressBarPercent(HealthProgressBar, HealthPercent);
}

void URinCBaseStatusWidget::UpdateMorale(float CurrentMorale, float MaxMorale, float MoraleThreshold)
{
    if (CurrentMorale < MoraleThreshold)
    {
        MoraleProgressBar->SetFillColorAndOpacity(BadMoraleColor);
    }
    else
    {
        MoraleProgressBar->SetFillColorAndOpacity(GoodMoraleColor);
    }

    float MoralePercent = CurrentMorale / MaxMorale;
    SetSmoothProgressBarPercent(MoraleProgressBar, MoralePercent);
}
