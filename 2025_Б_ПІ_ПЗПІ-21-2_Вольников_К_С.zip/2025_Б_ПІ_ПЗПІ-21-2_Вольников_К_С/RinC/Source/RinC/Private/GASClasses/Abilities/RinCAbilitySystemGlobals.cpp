// My copyright notice

#include "GASClasses/Abilities/RinCAbilitySystemGlobals.h"
#include "GASClasses/Abilities/RinCGameplayEffectContext.h"

FGameplayEffectContext* URinCAbilitySystemGlobals::AllocGameplayEffectContext() const
{
    return new FRinCGameplayEffectContext();
}
