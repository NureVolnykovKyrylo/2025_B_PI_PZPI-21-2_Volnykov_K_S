// My copyright notice

#include "GASClasses/Abilities/RinCBaseGameplayAbility.h"
#include "Subsystems/RinCUIManagerSubsystem.h"
#include "Kismet/GameplayStatics.h"
#include "HUD/RinCLayerType.h"

bool URinCBaseGameplayAbility::CheckCost(const FGameplayAbilitySpecHandle Handle, const FGameplayAbilityActorInfo* ActorInfo, OUT FGameplayTagContainer* OptionalRelevantTags) const
{
    bool CheckResult = Super::CheckCost(Handle, ActorInfo, OptionalRelevantTags);

    if (!ActorInfo || !ActorInfo->AvatarActor.Get()) return CheckResult;

    UGameInstance* GameInstance = UGameplayStatics::GetGameInstance(ActorInfo->AvatarActor.Get());
    if (!IsValid(GameInstance)) return CheckResult;

    URinCUIManagerSubsystem* UIManager = GameInstance->GetSubsystem<URinCUIManagerSubsystem>();
    if (!IsValid(UIManager)) return CheckResult;

    if (!CheckResult)
    {
        UIManager->PopContentFromLayer(ERinCLayerType::ModalLayer);
        UIManager->PushContentToLayer(ERinCLayerType::ModalLayer, SoftCostCheckFailedWidget);
    }

    return CheckResult;
}
