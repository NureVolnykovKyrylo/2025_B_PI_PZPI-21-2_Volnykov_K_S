// My copyright notice

#include "GASClasses/Calculations/MagnitudeCalculations/RinCActionPointsCostMagCalc.h"
#include "GASClasses/Abilities/RinCBaseGameplayAbility.h"

float URinCActionPointsCostMagCalc::CalculateBaseMagnitude_Implementation(const FGameplayEffectSpec& Spec) const
{
    const URinCBaseGameplayAbility* CurrentAbility = Cast<URinCBaseGameplayAbility>(Spec.GetContext().GetAbility());
    if (!IsValid(CurrentAbility)) return 0.0f;

    return -CurrentAbility->ActionPointCost;
}
