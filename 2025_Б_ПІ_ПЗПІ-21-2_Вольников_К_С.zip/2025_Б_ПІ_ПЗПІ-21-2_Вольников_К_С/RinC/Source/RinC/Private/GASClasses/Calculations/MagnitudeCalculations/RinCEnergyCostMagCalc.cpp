// My copyright notice

#include "GASClasses/Calculations/MagnitudeCalculations/RinCEnergyCostMagCalc.h"
#include "GASClasses/Abilities/RinCBaseGameplayAbility.h"

float URinCEnergyCostMagCalc::CalculateBaseMagnitude_Implementation(const FGameplayEffectSpec& Spec) const
{
    const URinCBaseGameplayAbility* CurrentAbility = Cast<URinCBaseGameplayAbility>(Spec.GetContext().GetAbility());
    if (!IsValid(CurrentAbility)) return 0.0f;

    return -CurrentAbility->EnergyCost;
}
