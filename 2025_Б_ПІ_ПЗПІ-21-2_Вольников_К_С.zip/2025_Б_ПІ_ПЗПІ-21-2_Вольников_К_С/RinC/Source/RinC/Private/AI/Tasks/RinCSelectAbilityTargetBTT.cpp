// My copyright notice

#include "AI/Tasks/RinCSelectAbilityTargetBTT.h"
#include "AIController.h"
#include "Characters/RinCBaseCharacter.h"
#include "RinCCombatComponent.h"
#include "AbilitySystemComponent.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "GASClasses/Abilities/RinCGASHelperLibrary.h"
#include "GASClasses/AttributeSets/RinCBaseAttributeSet.h"

URinCSelectAbilityTargetBTT::URinCSelectAbilityTargetBTT()
{
    NodeName = "RinC Select Ability Target";
}

EBTNodeResult::Type URinCSelectAbilityTargetBTT::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
    AAIController* OwnerAIController = OwnerComp.GetAIOwner();
    if (!IsValid(OwnerAIController)) return EBTNodeResult::Failed;

    ARinCBaseCharacter* OwnerCharacter = OwnerAIController->GetPawn<ARinCBaseCharacter>();
    if (!IsValid(OwnerCharacter)) return EBTNodeResult::Failed;

    UAbilitySystemComponent* OwnerASC = OwnerCharacter->GetAbilitySystemComponent();
    if (!IsValid(OwnerASC)) return EBTNodeResult::Failed;

    URinCCombatComponent* CombatComponent = OwnerCharacter->GetCombatComponent();
    if (!IsValid(CombatComponent)) return EBTNodeResult::Failed;

    const FGameplayTag ElementParentTag = FGameplayTag::RequestGameplayTag(FName("ElementType"), /*ErrorIfNotFound=*/true);

    FGameplayTag UsedAbilityElementalTag = TryGetUsedAbilityElementalTag(OwnerAIController, ElementParentTag);

    TArray<ARinCBaseCharacter*> TargetList = CombatComponent->GetCurrentTargetList();
    if (TargetList.Num() == 0) return EBTNodeResult::Failed;

    ARinCBaseCharacter* BestTarget = nullptr;
    float HighestPriority = -1.0f;

    for (ARinCBaseCharacter* Target : TargetList)
    {
        if (!IsValid(Target)) continue;

        const URinCBaseAttributeSet* TargetAttributeSet = Target->GetBaseAttributeSet();
        if (!IsValid(TargetAttributeSet)) continue;

        FGameplayTag TargetElementalTag = URinCGASHelperLibrary::GetElementTagFromContainer(Target->Tags, ElementParentTag);

        float CurrentPriority = CalculateTargetPriority(TargetAttributeSet, UsedAbilityElementalTag, TargetElementalTag);

        if (CurrentPriority > HighestPriority)
        {
            HighestPriority = CurrentPriority;
            BestTarget = Target;
        }
    }

    if (!IsValid(BestTarget))
    {
        CombatComponent->SetTargetCharacterById(0);
        return EBTNodeResult::Succeeded;
    }

    uint32 TargetCharacterId = TargetList.IndexOfByKey(BestTarget);
    CombatComponent->SetTargetCharacterById(TargetCharacterId);

    return EBTNodeResult::Succeeded;
}

FGameplayTag URinCSelectAbilityTargetBTT::TryGetUsedAbilityElementalTag(AAIController* OwnerAIController, const FGameplayTag& ElementParentTag)
{
    UBlackboardComponent* Blackboard = OwnerAIController->GetBlackboardComponent();;
    if (!IsValid(Blackboard)) return FGameplayTag::EmptyTag;

    ARinCBaseCharacter* OwnerCharacter = OwnerAIController->GetPawn<ARinCBaseCharacter>();
    if (!IsValid(OwnerCharacter)) return FGameplayTag::EmptyTag;

    UAbilitySystemComponent* OwnerASC = OwnerCharacter->GetAbilitySystemComponent();
    if (!IsValid(OwnerASC)) return FGameplayTag::EmptyTag;

    int32 UsedAbilityInput = Blackboard->GetValueAsInt(GetSelectedBlackboardKey());

    TArray<FGameplayAbilitySpec> ActivatableAbilities = OwnerASC->GetActivatableAbilities();
    for (const FGameplayAbilitySpec Spec : ActivatableAbilities)
    {
        if (Spec.InputID == UsedAbilityInput && Spec.InputPressed)
        {
            if (!IsValid(Spec.Ability)) continue;

            return URinCGASHelperLibrary::GetElementTagFromContainer(Spec.Ability->AbilityTags, ElementParentTag);
        }
    }

    return FGameplayTag::EmptyTag;
}

float URinCSelectAbilityTargetBTT::GetElementalMultiplier(const FGameplayTag& AbilityElementTag, const FGameplayTag& TargetElementTag)
{
    const FGameplayTag FireTag = FGameplayTag::RequestGameplayTag(FName("ElementType.Fire"));
    const FGameplayTag WaterTag = FGameplayTag::RequestGameplayTag(FName("ElementType.Water"));
    const FGameplayTag IceTag = FGameplayTag::RequestGameplayTag(FName("ElementType.Ice"));

    float Multiplier = 1.0f;

    /* Strong against */
    if ((AbilityElementTag == FireTag && TargetElementTag == IceTag) ||
        (AbilityElementTag == WaterTag && TargetElementTag == FireTag) ||
        (AbilityElementTag == IceTag && TargetElementTag == WaterTag))
    {
        Multiplier = 2.0f;
    }
    /* Weak against */
    else if ((AbilityElementTag == FireTag && TargetElementTag == WaterTag) ||
        (AbilityElementTag == WaterTag && TargetElementTag == IceTag) ||
        (AbilityElementTag == IceTag && TargetElementTag == FireTag))
    {
        Multiplier = 0.5f;
    }

    return Multiplier;
}

float URinCSelectAbilityTargetBTT::CalculateTargetPriority(const URinCBaseAttributeSet* TargetAttributeSet, const FGameplayTag& AbilityElementTag, const FGameplayTag& TargetElementTag)
{
    if (!IsValid(TargetAttributeSet))  return 0.0f;

    const FGameplayTag PsychicTag = FGameplayTag::RequestGameplayTag(FName("ElementType.Psychic"));

    /* When using a Psychic ability, the AI should prioritize targets with the HIGHEST current morale. */
    if (AbilityElementTag == PsychicTag)
    {
        return TargetAttributeSet->GetMorale();
    }

    const float ElementalWeight = 100.0f;
    const float HealthWeight = 75.0f;
    const float SurvivabilityWeight = 25.0f;
    const float MoraleWeight = 20.0f;

    /* Elemental advantage */
    const float ElementalMultiplier = GetElementalMultiplier(AbilityElementTag, TargetElementTag);
    const float ElementalScore = ElementalMultiplier * ElementalWeight;

    /* Health factor */
    const float CurrentHealth = TargetAttributeSet->GetHealth();
    const float MaxHealth = TargetAttributeSet->GetHealthMax();

    const float HealthFactor = (MaxHealth > 0) ? (1.0f - (CurrentHealth / MaxHealth)) : 0.0f;
    const float HealthScore = HealthFactor * HealthWeight;

    /* Deprioritize targets that are hard to hit/damage */
    const float Defense = TargetAttributeSet->GetDefense() / 100.0f;
    const float DodgeChance = TargetAttributeSet->GetDodgeChance() / 100.0f;

    const float SurvivabilityFactor = (1.0f - Defense) * (1.0f - DodgeChance);
    const float SurvivabilityScore = SurvivabilityFactor * SurvivabilityWeight;

    /* Prioritize targets with LOW morale */
    const float Morale = TargetAttributeSet->GetMorale() / 100.0f;

    const float MoraleFactor = (1.0f - Morale);
    const float MoraleScore = MoraleFactor * MoraleWeight;

    return ElementalScore + HealthScore + SurvivabilityScore + MoraleScore;
}