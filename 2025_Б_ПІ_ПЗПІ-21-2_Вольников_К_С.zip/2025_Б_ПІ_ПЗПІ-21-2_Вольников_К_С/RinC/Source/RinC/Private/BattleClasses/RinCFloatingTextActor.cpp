// Fill out your copyright notice in the Description page of Project Settings.

#include "BattleClasses/RinCFloatingTextActor.h"
#include "Components/WidgetComponent.h"
#include "Widgets/RinCFloatingTextWidget.h"

ARinCFloatingTextActor::ARinCFloatingTextActor()
{
    PrimaryActorTick.bCanEverTick = true;

    CustomRoot = CreateDefaultSubobject<USceneComponent>(TEXT("CustomRoot"));
    RootComponent = CustomRoot;

    FloatingTextWidgetComponent = CreateDefaultSubobject<UWidgetComponent>(TEXT("FloatingTextWidgetComponent"));
    FloatingTextWidgetComponent->SetupAttachment(CustomRoot);

    FloatingTextWidgetComponent->SetWidgetSpace(EWidgetSpace::Screen);
}

void ARinCFloatingTextActor::BeginPlay()
{
    Super::BeginPlay();

    URinCFloatingTextWidget* const FloatingTextWidget = Cast<URinCFloatingTextWidget>(FloatingTextWidgetComponent->GetWidget());
    if (!FloatingTextWidget) return;

    FloatingTextWidget->UpdateFloatingText(FloatingString);

    MoveWithLerpAndDestroy();
}

