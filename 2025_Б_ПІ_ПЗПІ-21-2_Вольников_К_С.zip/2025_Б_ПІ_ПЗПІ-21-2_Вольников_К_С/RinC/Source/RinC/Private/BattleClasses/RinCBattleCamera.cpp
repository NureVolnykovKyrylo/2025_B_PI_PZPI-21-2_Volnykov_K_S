// Fill out your copyright notice in the Description page of Project Settings.

#include "BattleClasses/RinCBattleCamera.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Controllers/RinCBasePlayerController.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

ARinCBattleCamera::ARinCBattleCamera()
    : InFrontOfPositionDistance(300.0f), InFrontOfPositionHeight(200.0f)
{
	PrimaryActorTick.bCanEverTick = false;

    BattleCameraRoot = CreateDefaultSubobject<USceneComponent>(TEXT("BattleCameraRoot"));
    BattleCameraRoot->SetupAttachment(RootComponent);

    CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
    CameraBoom->SetupAttachment(BattleCameraRoot);
    CameraBoom->TargetArmLength = 200.0f;

    FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
    FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
}

void ARinCBattleCamera::BeginPlay()
{
    Super::BeginPlay();

    DefaultFollowCameraRelativeLocation = FollowCamera->GetRelativeLocation();
    DefaultFollowCameraRelativeRotation = FollowCamera->GetRelativeRotation();
}

void ARinCBattleCamera::ResetComponentsTransform()
{
    FollowCamera->SetRelativeLocation(DefaultFollowCameraRelativeLocation);
    FollowCamera->SetRelativeRotation(DefaultFollowCameraRelativeRotation);
}

void ARinCBattleCamera::SetDynamicPosition(AActor* PositionActor)
{
    if (!PositionActor) return;

    ARinCBasePlayerController* const BasePlayerController = Cast<ARinCBasePlayerController>(UGameplayStatics::GetPlayerController(this, 0));
    if (!BasePlayerController) return;

    ResetComponentsTransform();

    FAttachmentTransformRules AttachmentRules(EAttachmentRule::SnapToTarget, EAttachmentRule::SnapToTarget, EAttachmentRule::KeepWorld, true);

    FDetachmentTransformRules DetachmentRules(EDetachmentRule::KeepWorld, EDetachmentRule::KeepWorld, EDetachmentRule::KeepWorld, false);

    DetachFromActor(DetachmentRules);
    AttachToActor(PositionActor, AttachmentRules);

    // TO DO move to combat component
    /*float BlendTime = 0.5f;
    BasePlayerController->SetViewTargetWithBlend(BasePlayerController->GetBattleCamera(), BlendTime);*/
}

void ARinCBattleCamera::SetFollowCameraLookToRotation(AActor* LookToActor)
{
    if (!LookToActor) return;

    FRotator NewRotation = UKismetMathLibrary::FindLookAtRotation(FollowCamera->GetComponentLocation(), LookToActor->GetActorLocation());

    SetFollowCameraLookToRotationWithLerp(FollowCamera->GetComponentRotation(), NewRotation);
    //FollowCamera->SetWorldRotation(NewRotation);
}

void ARinCBattleCamera::SetFollowCameraInFrontOfActor(AActor* PositionActor)
{
    if (!PositionActor) return;

    FVector PositionActorLocation = PositionActor->GetActorLocation();

    FVector NewFollowCameraLocation = PositionActorLocation + PositionActor->GetActorForwardVector() * InFrontOfPositionDistance;
    NewFollowCameraLocation.Z = InFrontOfPositionHeight;

    FollowCamera->SetWorldLocation(NewFollowCameraLocation);

    SetFollowCameraLookToRotation(PositionActor);
}

void ARinCBattleCamera::SetLookToRotation(AActor* LookToActor)
{
    if (!LookToActor) return;

    FRotator NewRotation = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), LookToActor->GetActorLocation());
    NewRotation.Pitch = 0.0;
    NewRotation.Roll = 0.0;

    SetLookToRotationWithLerp(GetActorRotation(), NewRotation);
    //SetActorRotation(NewRotation);
}



