// Fill out your copyright notice in the Description page of Project Settings.

#include "Cartridges/RinCBaseCartridge.h"
#include "Engine/AssetManager.h"
#include "DataAssets/RinCCartridgeData.h"
#include "AbilitySystemComponent.h"
#include "Miscellaneous/RinCResourceLoader.h"

ARinCBaseCartridge::ARinCBaseCartridge()
{
	PrimaryActorTick.bCanEverTick = false;
}

URinCCartridgeData* ARinCBaseCartridge::GetCartridgeData()
{
    return Cast<URinCCartridgeData>(RinCResourceLoader::GetPrimaryAssetObject(CartridgeDataPrimaryAssetId));
}

void ARinCBaseCartridge::BeginPlay()
{
	Super::BeginPlay();
}

void ARinCBaseCartridge::Equip(UAbilitySystemComponent* AbilitySystemComponent)
{
    URinCCartridgeData* CartridgeData = Cast<URinCCartridgeData>(RinCResourceLoader::GetPrimaryAssetObject(CartridgeDataPrimaryAssetId));
    if (!IsValid(CartridgeData)) return;

    ActiveGameplayEffectHandle = GrantStatsToAbilitySystem(AbilitySystemComponent);
    GameplayAbilitySpecHandle = CartridgeData->GrantAbilityToAbilitySystem(AbilitySystemComponent);
}

void ARinCBaseCartridge::Unequip(UAbilitySystemComponent* AbilitySystemComponent)
{
    if (!IsValid(AbilitySystemComponent)) return;

    AbilitySystemComponent->RemoveActiveGameplayEffect(ActiveGameplayEffectHandle);

    AbilitySystemComponent->ClearAbility(GameplayAbilitySpecHandle);
}

FActiveGameplayEffectHandle ARinCBaseCartridge::GrantStatsToAbilitySystem(UAbilitySystemComponent* AbilitySystemComponent)
{
    if (!AbilitySystemComponent) return FActiveGameplayEffectHandle();

    URinCCartridgeData* CartridgeData = Cast<URinCCartridgeData>(RinCResourceLoader::GetPrimaryAssetObject(CartridgeDataPrimaryAssetId));
    if (!IsValid(CartridgeData)) return FActiveGameplayEffectHandle();

    FGameplayEffectContextHandle ContextHandle = AbilitySystemComponent->MakeEffectContext();
    ContextHandle.AddInstigator(this, this);

    FGameplayEffectSpecHandle SpecHandle = AbilitySystemComponent->MakeOutgoingSpec(CartridgeData->GameplayEffectClass, 1.0f, ContextHandle);
    if (!SpecHandle.IsValid()) return FActiveGameplayEffectHandle();

    /* Apply each stat of a cartridge on a character's ability system component */
    for (const FRinCAppliedCartridgeStat& Stat : AppliedStats)
    {
        SpecHandle.Data.Get()->SetSetByCallerMagnitude(Stat.StatTag, Stat.Magnitude);
    }

    return AbilitySystemComponent->ApplyGameplayEffectSpecToSelf(*SpecHandle.Data.Get());
}

FPrimaryAssetId ARinCBaseCartridge::GetDataPrimaryAssetId()
{
    return CartridgeDataPrimaryAssetId;
}
