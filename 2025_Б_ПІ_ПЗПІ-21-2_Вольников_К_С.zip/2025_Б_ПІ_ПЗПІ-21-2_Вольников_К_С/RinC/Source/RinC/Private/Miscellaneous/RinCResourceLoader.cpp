// My copyright notice

#include "Miscellaneous/RinCResourceLoader.h"
#include "Engine/AssetManager.h"

TSharedPtr<FStreamableHandle> RinCResourceLoader::RequestAsyncLoad(const FSoftObjectPath& TargetToStream, FStreamableDelegate DelegateToCall)
{
    if (UAssetManager::IsInitialized())
    {
        return UAssetManager::GetStreamableManager().RequestAsyncLoad(TargetToStream, DelegateToCall);
    }
    return TSharedPtr<FStreamableHandle>();
}

TSharedPtr<FStreamableHandle> RinCResourceLoader::RequestAsyncLoad(TArray<FSoftObjectPath> TargetsToStream, FStreamableDelegate DelegateToCall)
{
    if (UAssetManager::IsInitialized())
    {
        return UAssetManager::GetStreamableManager().RequestAsyncLoad(TargetsToStream, DelegateToCall);
    }
    return TSharedPtr<FStreamableHandle>();
}

TSharedPtr<FStreamableHandle> RinCResourceLoader::LoadPrimaryAsset(const FPrimaryAssetId& AssetToLoad, const TArray<FName>& LoadBundles, 
    FStreamableDelegate DelegateToCall, TAsyncLoadPriority Priority)
{
    UAssetManager* const AssetManager = UAssetManager::GetIfInitialized();
    if (!IsValid(AssetManager)) return TSharedPtr<FStreamableHandle>();

    return AssetManager->LoadPrimaryAsset(AssetToLoad, LoadBundles, DelegateToCall, Priority);
}

TSharedPtr<FStreamableHandle> RinCResourceLoader::LoadPrimaryAssets(const TArray<FPrimaryAssetId>& AssetsToLoad, const TArray<FName>& LoadBundles, FStreamableDelegate DelegateToCall, TAsyncLoadPriority Priority)
{
    UAssetManager* const AssetManager = UAssetManager::GetIfInitialized();
    if (!IsValid(AssetManager)) return TSharedPtr<FStreamableHandle>();

    return AssetManager->LoadPrimaryAssets(AssetsToLoad, LoadBundles, DelegateToCall, Priority);
}

UObject* RinCResourceLoader::GetPrimaryAssetObject(const FPrimaryAssetId& PrimaryAssetId)
{
    UAssetManager* const AssetManager = UAssetManager::GetIfInitialized();
    if (!IsValid(AssetManager)) return nullptr;
    
    return AssetManager->GetPrimaryAssetObject(PrimaryAssetId);
}
