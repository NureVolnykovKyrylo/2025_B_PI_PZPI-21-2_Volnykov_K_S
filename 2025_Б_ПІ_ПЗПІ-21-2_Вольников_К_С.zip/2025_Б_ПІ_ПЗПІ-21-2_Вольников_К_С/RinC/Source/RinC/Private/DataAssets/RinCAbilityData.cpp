// My copyright notice


#include "DataAssets/RinCAbilityData.h"

FPrimaryAssetId URinCAbilityData::GetPrimaryAssetId() const
{
    return FPrimaryAssetId("Ability", GetFName());
}
