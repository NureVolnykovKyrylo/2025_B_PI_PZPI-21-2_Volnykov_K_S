// My copyright notice

#include "Interfaces/RinCAssetIdentifiable.h"

FPrimaryAssetId IRinCAssetIdentifiable::GetDataPrimaryAssetId()
{
    return FPrimaryAssetId();
}
