// Fill out your copyright notice in the Description page of Project Settings.

#include "Core/GameModes/RinCBaseGameMode.h"
#include "Kismet/GameplayStatics.h"
#include "Controllers/RinCBasePlayerController.h"
#include "RinCBaseBattleArena.h"
#include "Characters/RinCBaseCharacter.h"
#include "AbilitySystemComponent.h"
#include "AttributeSets/RinCBaseAttributeSet.h"
#include "GameStates/RinCBaseGameState.h"
#include "RinCPartyInventoryComponent.h"
#include "Subsystems/RinCUIManagerSubsystem.h"

ARinCBaseGameMode::ARinCBaseGameMode()
{
}

void ARinCBaseGameMode::PrepareBattle(ARinCBaseBattleArena* const BattleArena)
{
    if (!BattleArena) return;

    ARinCBasePlayerController* BasePlayerController = Cast<ARinCBasePlayerController>(UGameplayStatics::GetPlayerController(this, 0));
    if (!IsValid(BasePlayerController)) return;

    ARinCBaseGameState* BaseGameState = GetGameState<ARinCBaseGameState>();
    if (!IsValid(BaseGameState)) return;

    UGameInstance* GameInstance = UGameplayStatics::GetGameInstance(GetWorld());
    if (!IsValid(GameInstance)) return;

    URinCUIManagerSubsystem* UIManager = GameInstance->GetSubsystem<URinCUIManagerSubsystem>();
    if (!IsValid(UIManager)) return;

    BaseGameState->SetCurrentBattleArena(BattleArena);
    BasePlayerController->RemoveMappingContext(BasePlayerController->GetDefaultMappingContext());

    BattleArena->OnPrepareBattleStarted.RemoveAll(this);
    BattleArena->OnPrepareBattleEnded.RemoveAll(this);

    BattleArena->OnPrepareBattleStarted.AddUObject(this, &ThisClass::PushBattleTransitionWidget);
    BattleArena->OnPrepareBattleEnded.AddUObject(this, &ThisClass::StartBattle);

    BattleArena->SetupBattleArena();
}

void ARinCBaseGameMode::StartBattle()
{
    ARinCBasePlayerController* BasePlayerController = Cast<ARinCBasePlayerController>(UGameplayStatics::GetPlayerController(this, 0));
    if (!BasePlayerController) return;

    BasePlayerController->AddMappingContext(BasePlayerController->GetCombatMappingContext());

    ARinCBaseGameState* BaseGameState = GetGameState<ARinCBaseGameState>();
    if (!BaseGameState) return;

    BaseGameState->InitAliveCharactersLists();

    BaseGameState->OnBattleStarted.Broadcast();
}

void ARinCBaseGameMode::EndBattle(bool bWon)
{
    ARinCBaseGameState* BaseGameState = GetGameState<ARinCBaseGameState>();
    if (!IsValid(BaseGameState)) return;

    ARinCBasePlayerController* BasePlayerController = Cast<ARinCBasePlayerController>(UGameplayStatics::GetPlayerController(this, 0));
    if (!IsValid(BasePlayerController)) return;

    URinCPartyInventoryComponent* PartyInventoryComponent = BasePlayerController->GetPartyInventoryComponent();
    if (!IsValid(PartyInventoryComponent)) return;

    ARinCBaseBattleArena* BattleArena = BaseGameState->GetCurrentBattleArena();
    if (!IsValid(BattleArena)) return;

    /* Deside whether to give our player a reward and long-reset the arena, or short-reset the arena if the player has lost the battle */
    if (bWon)
    {
        BaseGameState->GrantRetrievedCartridges();

        BattleArena->Destroy();
    }
    else
    {
        BattleArena->TemporaryDisableArena(30.0f);
    }

    BasePlayerController->RemoveMappingContext(BasePlayerController->GetCombatMappingContext());
    BasePlayerController->AddMappingContext(BasePlayerController->GetDefaultMappingContext());

    BasePlayerController->DetachBattleCamera();

    PartyInventoryComponent->HidePartyHeroes();
    PartyInventoryComponent->SwitchToNextHero();
}

void ARinCBaseGameMode::SortBattleCharactersBySpeedAttribute(TArray<ARinCBaseCharacter*>& BattleCharacters)
{
    BattleCharacters.Sort([](const ARinCBaseCharacter& CharacterA, const ARinCBaseCharacter& CharacterB)
    {
        const UAbilitySystemComponent* AbilitySystemComponentA = CharacterA.GetAbilitySystemComponent();
        const UAbilitySystemComponent* AbilitySystemComponentB = CharacterB.GetAbilitySystemComponent();
        
        if (!AbilitySystemComponentA) return false;
        if (!AbilitySystemComponentB) return true;

        const URinCBaseAttributeSet* AttributeSetA = Cast<URinCBaseAttributeSet>(AbilitySystemComponentA->GetAttributeSet(URinCBaseAttributeSet::StaticClass()));
        const URinCBaseAttributeSet* AttributeSetB = Cast<URinCBaseAttributeSet>(AbilitySystemComponentB->GetAttributeSet(URinCBaseAttributeSet::StaticClass()));
        
        if (!AttributeSetA) return false;
        if (!AttributeSetB) return true;

        return AttributeSetA->GetSpeed() < AttributeSetB->GetSpeed();
    });
}

void ARinCBaseGameMode::PostLogin(APlayerController* NewPlayer)
{
    Super::PostLogin(NewPlayer);

    ARinCBasePlayerController* BasePlayerController = Cast<ARinCBasePlayerController>(NewPlayer);
    if (!BasePlayerController) return;

    URinCPartyInventoryComponent* const PartyInventoryComponent = BasePlayerController->GetPartyInventoryComponent();
    if (!PartyInventoryComponent) return;

    PartyInventoryComponent->InitializeHeroParty();
}

void ARinCBaseGameMode::PushBattleTransitionWidget()
{
    ARinCBaseGameState* BaseGameState = GetGameState<ARinCBaseGameState>();
    if (!IsValid(BaseGameState)) return;

    UGameInstance* GameInstance = UGameplayStatics::GetGameInstance(GetWorld());
    if (!IsValid(GameInstance)) return;

    URinCUIManagerSubsystem* UIManager = GameInstance->GetSubsystem<URinCUIManagerSubsystem>();
    if (!IsValid(UIManager)) return;

    UIManager->PopContentFromLayer(ERinCLayerType::ModalLayer);
    UIManager->PushContentToLayer(ERinCLayerType::ModalLayer, BaseGameState->GetBattleTransitionWidget());
}
