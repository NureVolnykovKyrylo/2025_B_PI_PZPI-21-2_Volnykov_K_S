// Fill out your copyright notice in the Description page of Project Settings.

#include "Core/Controllers/RinCBasePlayerController.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Engine/LocalPlayer.h"
#include "GameFramework/SpringArmComponent.h"
#include "NiagaraSystem.h"
#include "Characters/RinCBaseCharacter.h"
#include "Characters/RinCBaseHeroCharacter.h"
#include "RinCBattleCamera.h"
#include "GameStates/RinCBaseGameState.h"
#include "RinCCombatComponent.h"
#include "RinCPartyInventoryComponent.h"
#include "HUD/RinCBaseHUD.h"

ARinCBasePlayerController::ARinCBasePlayerController()
{
    PartyInventoryComponent = CreateDefaultSubobject<URinCPartyInventoryComponent>(TEXT("PartyInventoryComponent"));
}

void ARinCBasePlayerController::BeginPlay()
{
    Super::BeginPlay();

    if (!BattleCameraClass) return;
    ARinCBattleCamera* const SpawnedBattleCamera = GetWorld()->SpawnActor<ARinCBattleCamera>(BattleCameraClass);

    if (!SpawnedBattleCamera) return;
    BattleCamera = SpawnedBattleCamera;
}

void ARinCBasePlayerController::OnPossess(APawn* InPawn)
{
    Super::OnPossess(InPawn);
}

void ARinCBasePlayerController::AddMappingContext(UInputMappingContext* MappingContext)
{
    UEnhancedInputLocalPlayerSubsystem* const Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(GetLocalPlayer());
    if (Subsystem) Subsystem->AddMappingContext(MappingContext, 0);
}

void ARinCBasePlayerController::RemoveMappingContext(UInputMappingContext* MappingContext)
{
    UEnhancedInputLocalPlayerSubsystem* const Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(GetLocalPlayer());
    if (Subsystem) Subsystem->RemoveMappingContext(MappingContext);
}

void ARinCBasePlayerController::HandleCombatTargetSelection(bool bIsNextTarget)
{
    ARinCBaseCharacter* BaseCharacter = GetPawn<ARinCBaseCharacter>();
    if (!BaseCharacter) return;

    URinCCombatComponent* CombatComponent = BaseCharacter->GetCombatComponent();
    if (!CombatComponent) return;

    if (CombatComponent->GetCurrentTargetList().IsEmpty()) return;

    /* Remove Selection Reticle from the previously selected target */
    ARinCBaseCharacter* PrevTargetCharacter = CombatComponent->GetSelectedTargetCharacter();
    if (IsValid(PrevTargetCharacter)) PrevTargetCharacter->SetSelectionReticleState(false);

    int32 CurrentTargetIndex = CombatComponent->GetSelectedTargetId();
    if (bIsNextTarget)
    {
        CurrentTargetIndex < CombatComponent->GetCurrentTargetList().Num() - 1 
            ? CombatComponent->SetTargetCharacterById(CurrentTargetIndex + 1) 
            : CombatComponent->SetTargetCharacterById(0);
    }
    else
    {
        CurrentTargetIndex > 0
            ? CombatComponent->SetTargetCharacterById(CurrentTargetIndex - 1)
            : CombatComponent->SetTargetCharacterById(CombatComponent->GetCurrentTargetList().Num() - 1);
    }

    LookAtSelectedTarget();
}

void ARinCBasePlayerController::DetachBattleCamera()
{
    if (!BattleCamera) return;

    FDetachmentTransformRules DetachmentRules(EDetachmentRule::KeepWorld, EDetachmentRule::KeepWorld, EDetachmentRule::KeepWorld, false);

    BattleCamera->DetachFromActor(DetachmentRules); 
}

void ARinCBasePlayerController::LookAtSelectedTarget()
{
    if (!BattleCamera) return;

    ARinCBaseCharacter* ControlledCharacter = GetPawn<ARinCBaseCharacter>();
    if (!ControlledCharacter) return;

    URinCCombatComponent* CombatComponent = ControlledCharacter->GetCombatComponent();
    if (!CombatComponent) return;

    ARinCBaseCharacter* CurrentTargetCharacter = CombatComponent->GetSelectedTargetCharacter();
    if (!IsValid(CurrentTargetCharacter)) return;

    BattleCamera->SetFollowCameraLookToRotation(CurrentTargetCharacter);
    CurrentTargetCharacter->SetSelectionReticleState(true);
}

void ARinCBasePlayerController::SetupInputComponent()
{
    Super::SetupInputComponent();

    if (PartyInventoryComponent->GetCurrentPartyHeroes().IsEmpty()) return;

    UEnhancedInputLocalPlayerSubsystem* const Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(GetLocalPlayer());
    if (Subsystem) Subsystem->AddMappingContext(DefaultMappingContext, 0);

    UEnhancedInputComponent* const EnhancedInputComponent = Cast<UEnhancedInputComponent>(InputComponent);
    if (!(EnhancedInputComponent)) return;

    EnhancedInputComponent->BindAction(SwitchToNextHeroAction, ETriggerEvent::Started, PartyInventoryComponent, &URinCPartyInventoryComponent::SwitchToNextHero);

    ARinCBaseHUD* const BaseHUD = GetHUD<ARinCBaseHUD>();
    if (BaseHUD)
    {
        checkf(ToggleCharacterMenu, TEXT("ToggleCharacterMenu Action should be set!"))
        EnhancedInputComponent->BindAction(ToggleCharacterMenu, ETriggerEvent::Started, BaseHUD, &ARinCBaseHUD::ToggleCharacterMenu);
    }

    checkf(SelectNextTarget, TEXT("SelectNextTarget Action should be set!"))
    EnhancedInputComponent->BindAction(SelectNextTarget, ETriggerEvent::Started, this, &ARinCBasePlayerController::HandleCombatTargetSelection, true);

    checkf(SelectPreviousTarget, TEXT("SelectPreviousTarget Action should be set!"))
    EnhancedInputComponent->BindAction(SelectPreviousTarget, ETriggerEvent::Started, this, &ARinCBasePlayerController::HandleCombatTargetSelection, false);
}

