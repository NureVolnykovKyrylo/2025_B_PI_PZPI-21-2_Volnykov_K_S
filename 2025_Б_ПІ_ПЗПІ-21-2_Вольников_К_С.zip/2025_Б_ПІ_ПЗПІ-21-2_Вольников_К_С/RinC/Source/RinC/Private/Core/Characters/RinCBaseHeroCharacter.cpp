// Fill out your copyright notice in the Description page of Project Settings.

#include "Core/Characters/RinCBaseHeroCharacter.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputActionValue.h"
#include "AbilitySystemComponent.h"
#include "Helpers/RinCAbilityInputBindings.h"
#include "Kismet/GameplayStatics.h"
#include "Controllers/RinCBasePlayerController.h"
#include "RinCCombatComponent.h"
#include "GameStates/RinCBaseGameState.h"
#include "Kismet/GameplayStatics.h"
#include "Characters/Helpers/RinCCharacterInputs.h"

ARinCBaseHeroCharacter::ARinCBaseHeroCharacter()
{
}

void ARinCBaseHeroCharacter::Move(const FInputActionValue& Value)
{
    FVector2D MovementVector = Value.Get<FVector2D>();

    if (Controller != nullptr)
    {
        const FRotator Rotation = Controller->GetControlRotation();
        const FRotator YawRotation(0, Rotation.Yaw, 0);

        const FVector ForwardDirection = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);

        const FVector RightDirection = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);

        AddMovementInput(ForwardDirection, MovementVector.Y);
        AddMovementInput(RightDirection, MovementVector.X);
    }
}

void ARinCBaseHeroCharacter::Look(const FInputActionValue& Value)
{
    FVector2D LookAxisVector = Value.Get<FVector2D>();

    if (Controller != nullptr)
    {
        AddControllerYawInput(LookAxisVector.X);
        AddControllerPitchInput(LookAxisVector.Y);
    }
}

void ARinCBaseHeroCharacter::AbilityInputBindingPressedHandler(ERinCAbilityInput AbilityInput)
{
    UAbilitySystemComponent* CurrentAbilitySystemComponent = GetAbilitySystemComponent();
    if (!CurrentAbilitySystemComponent) return;

    CurrentAbilitySystemComponent->PressInputID(static_cast<uint32>(AbilityInput));

#if UE_EDITOR
    if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Green, FString::Printf(TEXT("Selected Ability with id %i"), static_cast<uint32>(AbilityInput)));
#endif // UE_EDITOR
}

void ARinCBaseHeroCharacter::HandleDeath()
{
    ARinCBaseGameState* const BaseGameState = Cast<ARinCBaseGameState>(UGameplayStatics::GetGameState(this));
    if (!BaseGameState) return;

    BaseGameState->RemoveFromAliveHeroCharacters(this);

    UAnimInstance* const AnimInstance = GetMesh()->GetAnimInstance();
    if (!AnimInstance) return;

    PlayAnimMontage(GetDeathMontage());
}

void ARinCBaseHeroCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);

    UEnhancedInputComponent* const EnhancedInputComponent = Cast<UEnhancedInputComponent>(PlayerInputComponent);
    if (!(EnhancedInputComponent)) return;

    if (!CharacterInputs) return;

    EnhancedInputComponent->BindAction(CharacterInputs->JumpAction, ETriggerEvent::Started, this, &ACharacter::Jump);
    EnhancedInputComponent->BindAction(CharacterInputs->JumpAction, ETriggerEvent::Completed, this, &ACharacter::StopJumping);

    EnhancedInputComponent->BindAction(CharacterInputs->MoveAction, ETriggerEvent::Triggered, this, &ARinCBaseHeroCharacter::Move);

    EnhancedInputComponent->BindAction(CharacterInputs->LookAction, ETriggerEvent::Triggered, this, &ARinCBaseHeroCharacter::Look);

    if (!CharacterInputs->AbilityInputBindings) return;

    for (const FRinCAbilityInputToInputActionBinding& Binding : CharacterInputs->AbilityInputBindings->Bindings)
    {
        EnhancedInputComponent->BindAction(Binding.InputAction, ETriggerEvent::Started, this, 
            &ARinCBaseHeroCharacter::AbilityInputBindingPressedHandler, Binding.AbilityInput);
    }

    if (!CombatComponent) return;

    EnhancedInputComponent->BindAction(CharacterInputs->ConfirmCharacterAbilityAction, ETriggerEvent::Started, CombatComponent, &URinCCombatComponent::HandleAbilityConfirm);

    EnhancedInputComponent->BindAction(CharacterInputs->EndCharacterTurnAction, ETriggerEvent::Started, CombatComponent, &URinCCombatComponent::EndCharacterTurn);
}

