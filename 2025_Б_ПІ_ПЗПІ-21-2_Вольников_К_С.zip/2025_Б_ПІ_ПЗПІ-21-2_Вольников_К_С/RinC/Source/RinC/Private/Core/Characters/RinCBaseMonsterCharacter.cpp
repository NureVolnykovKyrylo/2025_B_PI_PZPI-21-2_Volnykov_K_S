// Fill out your copyright notice in the Description page of Project Settings.

#include "Core/Characters/RinCBaseMonsterCharacter.h"
#include "GameStates/RinCBaseGameState.h"
#include "Kismet/GameplayStatics.h"
#include "Components/WidgetComponent.h"
#include "UI/BattleWidgets/RinCBaseStatusWidget.h"
#include "GASClasses/AttributeSets/RinCBaseAttributeSet.h"

ARinCBaseMonsterCharacter::ARinCBaseMonsterCharacter()
{
    StatusWidgetComponent = CreateDefaultSubobject<UWidgetComponent>(TEXT("StatusWidgetComponent"));
    StatusWidgetComponent->SetupAttachment(RootComponent);

    StatusWidgetComponent->SetWidgetSpace(EWidgetSpace::Screen);
}

void ARinCBaseMonsterCharacter::BeginPlay()
{
    Super::BeginPlay();
}

void ARinCBaseMonsterCharacter::HandleDeath()
{
    ARinCBaseGameState* const BaseGameState = Cast<ARinCBaseGameState>(UGameplayStatics::GetGameState(this));
    if (!BaseGameState) return;

    BaseGameState->RemoveFromAliveMonsterCharacters(this);

    TWeakObjectPtr<ARinCBaseMonsterCharacter> WeakBaseMonsterCharacter(this);

    UAnimInstance* const AnimInstance = GetMesh()->GetAnimInstance();
    if (!AnimInstance) return;

    PlayAnimMontage(GetDeathMontage());
}

void ARinCBaseMonsterCharacter::HealthChanged(const FOnAttributeChangeData& Data)
{
    Super::HealthChanged(Data);

    if (!IsValid(StatusWidgetComponent)) return;

    URinCBaseStatusWidget* StatusWidget = Cast<URinCBaseStatusWidget>(StatusWidgetComponent->GetWidget());
    if (!IsValid(StatusWidget)) return;

    if (!IsValid(AttributeSet)) return;

    float CurrentHealth = Data.NewValue;

    StatusWidget->UpdateHealth(CurrentHealth, AttributeSet->GetHealthMax());
}

void ARinCBaseMonsterCharacter::MoraleChanged(const FOnAttributeChangeData& Data)
{
    Super::MoraleChanged(Data);

    if (!IsValid(StatusWidgetComponent)) return;

    URinCBaseStatusWidget* StatusWidget = Cast<URinCBaseStatusWidget>(StatusWidgetComponent->GetWidget());
    if (!IsValid(StatusWidget)) return;

    if (!IsValid(AttributeSet)) return;

    float CurrentMorale = Data.NewValue;

    StatusWidget->UpdateMorale(CurrentMorale, AttributeSet->GetMoraleMax(), AttributeSet->GetMoraleThreshold());
}
