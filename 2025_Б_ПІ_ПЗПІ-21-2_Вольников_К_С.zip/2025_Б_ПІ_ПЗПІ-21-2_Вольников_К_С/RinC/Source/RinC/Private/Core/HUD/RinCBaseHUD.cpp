// My copyright notice

#include "Core/HUD/RinCBaseHUD.h"
#include "UI/Widgets/RinCPrimaryLayoutWidget.h"
#include "Subsystems/RinCUIManagerSubsystem.h"
#include "Kismet/GameplayStatics.h"
#include "GameStates/RinCBaseGameState.h"
#include "Characters/RinCBaseCharacter.h"
#include "Characters/RinCBaseHeroCharacter.h"
#include "Cartridges/RinCBaseCartridge.h"

void ARinCBaseHUD::BeginPlay()
{
    Super::BeginPlay();

    checkf(PrimaryLayoutWidgetClass, TEXT("PrimaryLayoutWidgetClass should be set!"))

    FocusInputOnGame();

    UWorld* World = GetWorld();
    if (!World) return;

    UGameInstance* GameInstance = UGameplayStatics::GetGameInstance(World);
    if (!IsValid(GameInstance)) return;

    URinCUIManagerSubsystem* UIManager = GameInstance->GetSubsystem<URinCUIManagerSubsystem>();
    if (!IsValid(UIManager)) return;

    /* Spawn and add to the viewport primary layout widget*/
    if (!PrimaryLayoutWidgetClass) return;
    PrimaryLayoutWidgetInstance = CreateWidget<URinCPrimaryLayoutWidget>(World, PrimaryLayoutWidgetClass);

    if (!PrimaryLayoutWidgetInstance) return;
    PrimaryLayoutWidgetInstance->AddToViewport();

    TWeakObjectPtr<URinCPrimaryLayoutWidget> WeakPrimaryLayoutWidgetInstance(PrimaryLayoutWidgetInstance);
    UIManager->SetWeakPrimaryLayoutWidget(WeakPrimaryLayoutWidgetInstance);

    /* Bind other events */
    ARinCBaseGameState* BaseGameState = Cast<ARinCBaseGameState>(UGameplayStatics::GetGameState(World));
    if (!IsValid(BaseGameState)) return;

    BaseGameState->OnBattleStarted.AddUObject(this, &ThisClass::PushBattleGameHUDWidgetToGameLayer);
    BaseGameState->OnBattleEnded.AddUObject(this, &ThisClass::PopContentFromGameLayer);
    BaseGameState->OnTurnStart.AddUObject(this, &ThisClass::PushTurnPopUp);
    BaseGameState->OnCartirdgesGranted.AddUObject(this, &ThisClass::PushNewCartridgePopUp);
}

void ARinCBaseHUD::FocusInputOnGame()
{
    APlayerController* const PlayerController = GetOwningPlayerController();
    if (!PlayerController) return;

    FInputModeGameOnly InputMode;
    PlayerController->SetInputMode(InputMode);
    PlayerController->SetShowMouseCursor(false);
}

void ARinCBaseHUD::FocusInputOnGameAndUI()
{
    APlayerController* const PlayerController = GetOwningPlayerController();
    if (!PlayerController) return;

    FInputModeGameAndUI InputMode;
    PlayerController->SetInputMode(InputMode);
    PlayerController->SetShowMouseCursor(true);
}

void ARinCBaseHUD::ToggleCharacterMenu()
{
    checkf(!SoftCharacterMenuClass.IsNull(), TEXT("SoftCharacterMenuClass should be set!"))

    UGameInstance* const GameInstance = UGameplayStatics::GetGameInstance(GetWorld());
    if (!GameInstance) return;

    URinCUIManagerSubsystem* const UIManager = GameInstance->GetSubsystem<URinCUIManagerSubsystem>();
    if (!UIManager) return;

    if (UIManager->IsContentCollapsedInLayer(ERinCLayerType::GameMenuLayer, SoftCharacterMenuClass))
    {
        UIManager->PushContentToLayerWithCheck(ERinCLayerType::GameMenuLayer, SoftCharacterMenuClass);
        FocusInputOnGameAndUI();
        return;
    }

    UIManager->CollapseContentInLayer(ERinCLayerType::GameMenuLayer);
    FocusInputOnGame();
}

void ARinCBaseHUD::PushBattleGameHUDWidgetToGameLayer()
{
    checkf(!SoftBattleGameHUDWidgetClass.IsNull(), TEXT("SoftBattleGameHUDWidgetClass should be set!"))

    UGameInstance* GameInstance = UGameplayStatics::GetGameInstance(GetWorld());
    if (!IsValid(GameInstance)) return;

    URinCUIManagerSubsystem* UIManager = GameInstance->GetSubsystem<URinCUIManagerSubsystem>();
    if (!IsValid(UIManager)) return;

    UIManager->PushContentToLayer(ERinCLayerType::GameLayer, SoftBattleGameHUDWidgetClass);

    FocusInputOnGameAndUI();
}

void ARinCBaseHUD::PushTurnPopUp(ARinCBaseCharacter* TurnCharacter)
{
    checkf(!SoftYourTurnWidgetClass.IsNull(), TEXT("SoftYourTurnWidgetClass should be set!"))
    checkf(!SoftEnemyTurnWidgetClass.IsNull(), TEXT("SoftEnemyTurnWidgetClass should be set!"))

    if (!IsValid(TurnCharacter)) return;

    UGameInstance* GameInstance = UGameplayStatics::GetGameInstance(GetWorld());
    if (!IsValid(GameInstance)) return;

    URinCUIManagerSubsystem* UIManager = GameInstance->GetSubsystem<URinCUIManagerSubsystem>();
    if (!IsValid(UIManager)) return;

    UIManager->PopContentFromLayer(ERinCLayerType::ModalLayer);

    if (TurnCharacter->IsA<ARinCBaseHeroCharacter>())
    {
        UIManager->PushContentToLayer(ERinCLayerType::ModalLayer, SoftYourTurnWidgetClass);
    }
    else
    {
        UIManager->PushContentToLayer(ERinCLayerType::ModalLayer, SoftEnemyTurnWidgetClass);
    }
}

void ARinCBaseHUD::PushNewCartridgePopUp()
{
    checkf(!SoftNewCartridgePopUpWidgetClass.IsNull(), TEXT("SoftYourTurnWidgetClass should be set!"))

    UGameInstance* GameInstance = UGameplayStatics::GetGameInstance(GetWorld());
    if (!IsValid(GameInstance)) return;

    URinCUIManagerSubsystem* UIManager = GameInstance->GetSubsystem<URinCUIManagerSubsystem>();
    if (!IsValid(UIManager)) return;

    UIManager->PopContentFromLayer(ERinCLayerType::ModalLayer);
    UIManager->PushContentToLayer(ERinCLayerType::ModalLayer, SoftNewCartridgePopUpWidgetClass);
}

void ARinCBaseHUD::PopContentFromGameLayer()
{
    UGameInstance* GameInstance = UGameplayStatics::GetGameInstance(GetWorld());
    if (!IsValid(GameInstance)) return;

    URinCUIManagerSubsystem* UIManager = GameInstance->GetSubsystem<URinCUIManagerSubsystem>();
    if (!IsValid(UIManager)) return;

    UIManager->PopContentFromLayer(ERinCLayerType::GameLayer);

    FocusInputOnGame();
}