// Fill out your copyright notice in the Description page of Project Settings.

#include "Components/RinCCombatComponent.h"
#include "Characters/RinCBaseHeroCharacter.h"
#include "Characters/RinCBaseMonsterCharacter.h"
#include "Characters/RinCBaseCharacter.h"
#include "GameStates/RinCBaseGameState.h"
#include "Kismet/GameplayStatics.h"
#include "Controllers/RinCBasePlayerController.h"
#include "RinCBattleCamera.h"
#include "RinCBaseBattleArena.h"
#include "RinCBattleHelperHeroOpposite.h"
#include "Kismet/GameplayStatics.h"
#include "RinCBattleCamera.h"
#include "AbilitySystemComponent.h"
#include "Helpers/RinCAbilityInput.h"
#include "Abilities/GameplayAbilityTypes.h"
#include "RinCFloatingTextActor.h"
#include "AI/Controllers/RinCBaseAIController.h"

URinCCombatComponent::URinCCombatComponent()
    : SelectedTargetCharacter(nullptr), SelectedTargetId(-1), bIsCurrentAbilityTargetingAllies(false)
{
	PrimaryComponentTick.bCanEverTick = false;
}

void URinCCombatComponent::BeginPlay()
{
	Super::BeginPlay();

    UAbilitySystemComponent* OwnerASC = GetOwnerASC();
    if (!IsValid(OwnerASC)) return;

    ARinCBaseGameState* BaseGameState = Cast<ARinCBaseGameState>(UGameplayStatics::GetGameState(this));
    if (!IsValid(BaseGameState)) return;

    OwnerASC->OnAbilityEnded.AddUObject(this, &URinCCombatComponent::OnAbilityEnded);

    BaseGameState->OnBattleEnded.AddUObject(this, &ThisClass::EndCharacterTurn);
    BaseGameState->OnBattleEnded.AddUObject(this, &ThisClass::RemoveBattleActiveGameplayEffects);

    BaseGameState->OnTurnStart.AddUObject(this, &ThisClass::TryStartCharacterTurn);

    TWeakObjectPtr<UAbilitySystemComponent> WeakASC(OwnerASC);
    BaseGameState->OnRoundEnded.AddUObject(BaseGameState, &ARinCBaseGameState::ResetRoundStats, WeakASC);
    BaseGameState->OnBattleEnded.AddUObject(BaseGameState, &ARinCBaseGameState::ResetStatsAfterBattle, WeakASC);

    OnCharacterTurnEnded.AddUObject(BaseGameState, &ARinCBaseGameState::ExecuteQueueTurn);
}

void URinCCombatComponent::TryStartCharacterTurn(ARinCBaseCharacter* TurnCharacter)
{
    ARinCBaseCharacter* OwnerCharacter = GetOwner<ARinCBaseCharacter>();
    if (!IsValid(OwnerCharacter) || !IsValid(TurnCharacter)) return;

    /* If it's not our turn, than do nothing */
    if (OwnerCharacter != TurnCharacter) return;

    ARinCBasePlayerController* PlayerController = Cast<ARinCBasePlayerController>(UGameplayStatics::GetPlayerController(this, 0));
    if (!IsValid(PlayerController)) return;

    /* Set default battle camera focus, helpful for the first monster turn */
    SetBattleCameraDefaultFocus(PlayerController->GetPawn<ARinCBaseCharacter>());
    PlayerController->SetViewTarget(PlayerController->GetBattleCamera());

    if (OwnerCharacter->IsA(ARinCBaseHeroCharacter::StaticClass()))
    {
        PlayerController->Possess(OwnerCharacter);

        float Time = 0.5f;
        PlayerController->SetViewTargetWithBlend(PlayerController->GetBattleCamera(), Time);
        SetBattleCameraDefaultFocus(OwnerCharacter);
    }
    else
    {
        HandleMonsterTurn();
    }
}

void URinCCombatComponent::EndCharacterTurn()
{
    OnCharacterTurnEnded.Broadcast();

#if UE_EDITOR
    if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Red, TEXT("Ended Character Turn"));
#endif // UE_EDITOR
}

void URinCCombatComponent::SetTargetCharacterById(uint32 Id)
{
    SelectedTargetId = Id;

    if (CurrentTargetList.IsValidIndex(Id))
    {
        SelectedTargetCharacter = CurrentTargetList[Id];
    }
}

void URinCCombatComponent::SetBattleCameraDefaultFocus(ARinCBaseCharacter* OtherCharacter)
{
    AActor* OwnerActor = GetOwner();
    if (!IsValid(OwnerActor)) return;

    ARinCBattleCamera* BattleCamera = GetBattleCamera();
    if (!IsValid(BattleCamera)) return;

    if (OwnerActor->IsA(ARinCBaseHeroCharacter::StaticClass()))
    {
        BattleCamera->SetDynamicPosition(OwnerActor);
    }
    else if (OtherCharacter && OtherCharacter->IsA(ARinCBaseHeroCharacter::StaticClass()))
    {
        BattleCamera->SetDynamicPosition(OtherCharacter);
    }
}

void URinCCombatComponent::SetBattleCameraAttackFocus(ARinCBaseCharacter* OtherCharacter)
{
    AActor* const OwnerActor = GetOwner();
    if (!OwnerActor) return;

    ARinCBattleCamera* BattleCamera = GetBattleCamera();
    if (!IsValid(BattleCamera)) return;

    if (OwnerActor->IsA(ARinCBaseHeroCharacter::StaticClass()))
    {
        BattleCamera->SetDynamicPosition(OwnerActor);
        BattleCamera->SetLookToRotation(OtherCharacter);
    }
    else if (OtherCharacter && OtherCharacter->IsA(ARinCBaseHeroCharacter::StaticClass()))
    {
        BattleCamera->SetDynamicPosition(OtherCharacter);
        BattleCamera->SetLookToRotation(OwnerActor);
    }
}

void URinCCombatComponent::SetBattleCameraBuffFocus(ARinCBaseCharacter* OtherCharacter)
{
    if (!OtherCharacter) return;

    ARinCBattleCamera* BattleCamera = GetBattleCamera();
    if (!IsValid(BattleCamera)) return;

    BattleCamera->SetFollowCameraInFrontOfActor(OtherCharacter);
}

void URinCCombatComponent::HandleMonsterTurn()
{
    ARinCBaseCharacter* OwnerCharacter = GetOwner<ARinCBaseCharacter>();
    if (!IsValid(OwnerCharacter)) return;

    ARinCBaseAIController* AIController = OwnerCharacter->GetController<ARinCBaseAIController>();
    if (!IsValid(AIController)) return;

    AIController->RunBattleBehaviorTree();

#if UE_EDITOR
    if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Green, TEXT("Monster character turn!"));
#endif // UE_EDITOR
}

void URinCCombatComponent::OnAbilityEnded(const FAbilityEndedData& AbilityEndedData)
{
    SetBattleCameraDefaultFocus(SelectedTargetCharacter);
    ClearCurrentTargetListAndSelectedTarget();

    ARinCBaseMonsterCharacter* OwnerMonster = GetOwner<ARinCBaseMonsterCharacter>();
    if (IsValid(OwnerMonster))
    {
        EndCharacterTurn();

        ARinCBaseAIController* AIController = OwnerMonster->GetController<ARinCBaseAIController>();
        if (!IsValid(AIController)) return;

        AIController->StopBattleBehaviorTree();
    }
}

UAbilitySystemComponent* URinCCombatComponent::GetOwnerASC()
{
    ARinCBaseCharacter* OwnerCharacter = GetOwner<ARinCBaseCharacter>();
    if (!IsValid(OwnerCharacter)) return nullptr;

    return OwnerCharacter->GetAbilitySystemComponent();
}

ARinCBattleCamera* URinCCombatComponent::GetBattleCamera()
{
    ARinCBasePlayerController* PlayerController = Cast<ARinCBasePlayerController>(UGameplayStatics::GetPlayerController(this, 0));
    if (!IsValid(PlayerController)) return nullptr;

    return PlayerController->GetBattleCamera();
}

void URinCCombatComponent::RemoveBattleActiveGameplayEffects()
{
    UAbilitySystemComponent* OwnerASC = GetOwnerASC();
    if (!IsValid(OwnerASC)) return;

    for (const FActiveGameplayEffectHandle& Handle : ActiveGameplayEffectHandles)
    {
        OwnerASC->RemoveActiveGameplayEffect(Handle);
    }

    ActiveGameplayEffectHandles.Empty();
}

ARinCBaseCharacter* URinCCombatComponent::GetSelectedTargetCharacter() const
{
    return SelectedTargetCharacter;
}

void URinCCombatComponent::SetCurrentTargetList(bool bTargetAllies)
{
    AActor* OwnerActor = GetOwner();
    if (!OwnerActor) return;

    ARinCBaseGameState* BaseGameState = Cast<ARinCBaseGameState>(UGameplayStatics::GetGameState(this));
    if (!BaseGameState) return;

    bIsCurrentAbilityTargetingAllies = bTargetAllies;

    if (OwnerActor->IsA(ARinCBaseHeroCharacter::StaticClass()))
    {
        CurrentTargetList = bIsCurrentAbilityTargetingAllies
            ? BaseGameState->GetCurrentAliveHeroCharacters()
            : BaseGameState->GetCurrentAliveMonsterCharacters();
    }
    else
    {
        CurrentTargetList = bIsCurrentAbilityTargetingAllies
            ? BaseGameState->GetCurrentAliveMonsterCharacters()
            : BaseGameState->GetCurrentAliveHeroCharacters();
    }

    if (CurrentTargetList.IsEmpty()) return;

    /* Set inital selected character */
    SelectedTargetId = 0;
    SelectedTargetCharacter = CurrentTargetList[SelectedTargetId];

    if (OwnerActor->IsA(ARinCBaseHeroCharacter::StaticClass())) 
    {
        SetInitialBattleCameraTargetView();
    }
}

void URinCCombatComponent::ClearCurrentTargetListAndSelectedTarget()
{
    CurrentTargetList.Empty();
    SelectedTargetId = -1;
    SelectedTargetCharacter = nullptr;
}

void URinCCombatComponent::SetInitialBattleCameraTargetView()
{
    ARinCBaseGameState* BaseGameState = Cast<ARinCBaseGameState>(UGameplayStatics::GetGameState(this));
    if (!IsValid(BaseGameState)) return;

    ARinCBaseBattleArena* CurrentBattleArena = BaseGameState->GetCurrentBattleArena();
    if (!IsValid(CurrentBattleArena)) return;

    ARinCBattleHelperHeroOpposite* BattleHelperHeroOpposite = CurrentBattleArena->GetBattleHelperHeroOpposite();
    if (!IsValid(BattleHelperHeroOpposite)) return;

    ARinCBasePlayerController* BasePlayerController = Cast<ARinCBasePlayerController>(UGameplayStatics::GetPlayerController(this, 0));
    if (!IsValid(BasePlayerController)) return;

    ARinCBattleCamera* BattleCamera = BasePlayerController->GetBattleCamera();
    if (!IsValid(BattleCamera)) return;

    if (bIsCurrentAbilityTargetingAllies)
    {
        BattleCamera->SetDynamicPosition(BattleHelperHeroOpposite);
    }
    else
    {
        AActor* OwnerActor = GetOwner();
        if (!OwnerActor) return;

        BattleCamera->SetDynamicPosition(OwnerActor);
    }

    BasePlayerController->LookAtSelectedTarget();
}

void URinCCombatComponent::HandleAbilityConfirm()
{
    UAbilitySystemComponent* OwnerASC = GetOwnerASC();
    if (!IsValid(OwnerASC)) return;

    OwnerASC->InputConfirm();

    /* Remove Selection Reticle from the previously selected target */
    ARinCBaseCharacter* TargetCharacter = GetSelectedTargetCharacter();
    if (IsValid(TargetCharacter)) TargetCharacter->SetSelectionReticleState(false);

#if UE_EDITOR
    if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Green, TEXT("Confirmed selected Ability!"));
#endif // UE_EDITOR
}

void URinCCombatComponent::SpawnFloatingTextActor(const FString& InString, FTransform SpawnTransform)
{
    if (!IsValid(FloatingTextActorClass)) return;

    ARinCFloatingTextActor* FloatingTextActor = GetWorld()->SpawnActorDeferred<ARinCFloatingTextActor>(FloatingTextActorClass, SpawnTransform);
    FloatingTextActor->SetFloatingTextString(InString);
    FloatingTextActor->FinishSpawning(SpawnTransform);
}

void URinCCombatComponent::AddActiveGameplayEffect(FActiveGameplayEffectHandle NewEffectHandle)
{
    ActiveGameplayEffectHandles.Add(NewEffectHandle);
}
