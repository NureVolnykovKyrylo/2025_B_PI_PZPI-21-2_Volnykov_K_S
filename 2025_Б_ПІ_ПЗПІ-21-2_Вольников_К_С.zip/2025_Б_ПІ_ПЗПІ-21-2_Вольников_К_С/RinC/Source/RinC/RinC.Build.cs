// Copyright Epic Games, Inc. All Rights Reserved.

using System.IO;
using UnrealBuildTool;

public class RinC : ModuleRules
{
	public RinC(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore", "EnhancedInput", "Niagara", "SlateCore" });
        PrivateDependencyModuleNames.AddRange(new string[] { "GameplayAbilities", "GameplayTags", "GameplayTasks" });

        PublicIncludePaths.AddRange(new string[]
        {
            "RinC/Public/Core",
            "RinC/Public/GASClasses",
            "RinC/Public/Components",
            "RinC/Public/BattleClasses",
            "RinC/Public/Cartridges",
            "RinC/Public/UI"
        });
    }
}
